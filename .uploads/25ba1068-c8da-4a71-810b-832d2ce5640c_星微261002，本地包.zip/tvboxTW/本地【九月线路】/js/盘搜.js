import {
    Quark
} from "../depend/q.js";
import {
    Baidu
} from "../depend/b.js";
import {
    UC
} from "../depend/u.js";

let debug = 1;
let siteName = '盘搜';
let apiHost = 'https://so.252035.xyz/';
let panTypes = "baidu,quark,uc";
let downloadThreads = '60';
let proxyUrl = 'http://127.0.0.1:3334/?url=';
let proxyImgUrl = 'https://wsrv.nl/?url=';
let defaultImg = 'https://a1.boltp.com/2026/06/07/6a25130953ffd.png';
let maxResults = 99;
let maxPages = 3;
let maxLinksPerItem = 10;

let lineOrder = ['百度', '夸克', 'UC'];

const rule = {
    search: '/api/search'
};

let quarkInfinite = 0;
let quarkOrig = 0;
let quarkTransfer = 1;
let enableProxy = 0;
let enableImage = 1;

const headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36"
};

const resMap = {
    'low': '流畅',
    'normal': '标清',
    'high': '高清',
    'super': '超清',
    '4k': '4K',
    '2k': '2K',
    'hdr': 'HDR',
    'dolby_vision': 'HDR',
    'M3U8_AUTO_480': '480P',
    'M3U8_AUTO_720': '720P',
    'M3U8_AUTO_1080': '1080P',
    'M3U8_AUTO_2K': '2K',
    'M3U8_AUTO_4K': '4K'
};

const typeMap = {
    'baidu': {
        name: '百度',
        icon: 'https://cnb.cool/zhyadc/YsBox/-/git/raw/main/images/icon_cookie/百度.png',
        handler: Baidu
    },
    'quark': {
        name: '夸克',
        icon: 'https://cnb.cool/zhyadc/YsBox/-/git/raw/main/images/icon_cookie/夸克.png',
        handler: Quark
    },
    'uc': {
        name: 'UC',
        icon: 'https://cnb.cool/zhyadc/YsBox/-/git/raw/main/images/icon_cookie/UC.png',
        handler: UC
    }
};

function buildSearchUrl(wd, page) {
    return `${apiHost}${rule.search}?kw=${encodeURIComponent(wd)}&res=all`;
}

async function init(cfg) {
    const start = Date.now();

    let ext = cfg.ext !== undefined ? cfg.ext : cfg;
    if (typeof ext === 'string' && ext.includes('$')) {
        const [url, name] = ext.split('$');
        if (name) siteName = name;
        const html = await request(url);
        if (html) {
            let configObj = JSON.parse(html);
            if (name && configObj?.[name]) configObj = configObj[name];
            await syncCookies(configObj);
        }
    } else if (ext && typeof ext === 'object') {
        await syncCookies(ext);
    } else {
        await syncCookies(null);
    }

    log(logLevel.info, '初始化', `========== ${siteName} ==========`);
    log(logLevel.info, '状态', `夸克:${Quark.cookie ? '已设置' : '未设置'} 百度:${Baidu.cookie ? '已设置' : '未设置'} UC:${UC.cookie ? '已设置' : '未设置'}`);
    log(logLevel.info, '配置', `原画:${quarkOrig} 无限:${quarkInfinite} 转存:${quarkTransfer} 代理:${enableProxy}`);
    log(logLevel.info, '搜索', `Host:${apiHost} 类型:${panTypes} 线程:${downloadThreads} 限制:${maxResults} 翻页:${maxPages}`);
    log(logLevel.info, '线路排序', `顺序: ${lineOrder.join(' → ')}`);
    logTime(start, "初始化完成");
}

function home() {
    return JSON.stringify({
        class: [{
            type_id: 'search',
            type_name: '这是网盘搜索，没有分类'
        }]
    });
}

async function homeVod() {
    return await category('search', 1);
}

async function category(tid) {
    if (tid === 'search') {
        return JSON.stringify({
            list: [{
                vod_id: 'only_search',
                vod_name: '🔍 网盘资源搜索',
                vod_pic: defaultImg
            }]
        });
    }
    return JSON.stringify({
        list: []
    });
}

async function detail(id) {
    const start = Date.now();

    let shareUrls = [];
    let vod_name = '';
    let coverImage = '';

    try {
        const parsed = JSON.parse(id);
        if (parsed.links && Array.isArray(parsed.links)) {
            shareUrls = parsed.links;
            vod_name = parsed.title || '网盘资源';
            coverImage = parsed.coverImage || '';
        } else if (parsed.url) {
            shareUrls = [{
                url: parsed.url,
                type: parsed.type || 'unknown'
            }];
            vod_name = parsed.title || '网盘资源';
        } else {
            throw new Error('Invalid JSON format');
        }
    } catch (e) {
        let separatorIndex = id.indexOf('|');
        if (separatorIndex !== -1) {
            let shareUrl = id.substring(0, separatorIndex);
            vod_name = id.substring(separatorIndex + 1);
            shareUrls = [{
                url: shareUrl,
                type: 'unknown'
            }];
        } else {
            shareUrls = [{
                url: id,
                type: 'unknown'
            }];
            vod_name = '网盘资源';
        }
    }

    const totalLinks = shareUrls.length;
    console.log(`【${siteName}】详情解析开始: ${vod_name} - 共${totalLinks}个链接`);

    const typeCount = {
        'quark': 0,
        'baidu': 0,
        'uc': 0,
        'unknown': 0
    };
    for (let link of shareUrls) {
        let type = (link.type || '').toLowerCase();
        if (typeCount[type] !== undefined) typeCount[type]++;
        else typeCount.unknown++;
    }
    console.log(`【${siteName}】链接分布: 夸克=${typeCount.quark}, 百度=${typeCount.baidu}, UC=${typeCount.uc}, 未知=${typeCount.unknown}`);

    const grouped = {
        '夸克': [],
        '百度': [],
        'UC': []
    };

    for (let link of shareUrls) {
        let type = (link.type || '').toLowerCase();
        let groupName = typeMap[type]?.name;
        if (groupName && !grouped[groupName].includes(link.url)) {
            grouped[groupName].push(link);
        }
    }

    const parseStats = {
        '夸克': {
            total: 0,
            success: 0,
            failed: 0,
            failedUrls: []
        },
        '百度': {
            total: 0,
            success: 0,
            failed: 0,
            failedUrls: []
        },
        'UC': {
            total: 0,
            success: 0,
            failed: 0,
            failedUrls: []
        }
    };

    const processPan = async (typeKey, links) => {
        const typeInfo = typeMap[typeKey];
        if (!links.length || !typeInfo?.handler) {
            if (links.length) {
                const groupName = typeInfo?.name || typeKey;
                parseStats[groupName] = {
                    total: links.length,
                    success: 0,
                    failed: links.length,
                    failedUrls: links.map(l => l.url)
                };
            }
            return null;
        }

        const groupName = typeInfo.name;
        parseStats[groupName].total = links.length;

        let allUrls = [];
        let allImgs = [];
        let successCount = 0;
        let failedUrls = [];

        for (let link of links) {
            try {
                let shareData = typeInfo.handler.getShareData(link.url);
                if (!shareData) {
                    console.log(`【${siteName}】${groupName}解析失败: 无法获取分享数据 - ${link.url}`);
                    failedUrls.push(link.url);
                    continue;
                }

                if (link.password) shareData.pwd = link.password;

                let files = await typeInfo.handler.getFilesByShareUrl(shareData);
                if (!files?.length) {
                    console.log(`【${siteName}】${groupName}解析失败: 无文件列表 - ${link.url}`);
                    failedUrls.push(link.url);
                    continue;
                }

                successCount++;
                let url = files.map(v => {
                    let size = v.size ? ` 【${formatSize(v.size)}】` : '';
                    let name = (v.file_name || v.name || '').replace(/\s+/g, ' ').trim();
                    if (typeKey === 'baidu') {
                        let info = {
                            surl: shareData.surl,
                            pwd: shareData.pwd || ''
                        };
                        return `${name}${size}$${[v.path, v.uk, v.shareid, v.fsid, JSON.stringify(info)].join('*')}`;
                    }
                    return `${name}${size}$${[shareData.shareId, v.stoken, v.fid, v.share_fid_token].join('*')}`;
                }).join('#');

                let imgs = files.map(v => v.thumbnail || v.thumb || '').join('#');
                allUrls.push(url);
                allImgs.push(imgs);
            } catch (e) {
                console.error(`【${siteName}】${groupName}处理链接失败: ${e.message} - ${link.url}`);
                failedUrls.push(link.url);
            }
        }

        parseStats[groupName].success = successCount;
        parseStats[groupName].failed = links.length - successCount;
        parseStats[groupName].failedUrls = failedUrls;

        if (allUrls.length) {
            return {
                type: typeInfo.name,
                url: allUrls.join('#'),
                imgs: allImgs.join('#')
            };
        }
        return null;
    };

    const results = await Promise.all([
        processPan('quark', grouped['夸克']),
        processPan('baidu', grouped['百度']),
        processPan('uc', grouped['UC'])
    ]);

    console.log(`【${siteName}】解析统计:`);
    for (const [pan, stats] of Object.entries(parseStats)) {
        if (stats.total > 0) {
            console.log(`  ${pan}: 总计${stats.total}个, 成功${stats.success}个, 失败${stats.failed}个`);
            if (stats.failed > 0) {
                console.log(`    失败链接: ${stats.failedUrls.join(', ')}`);
            }
        }
    }

    let play_from = [];
    let play_url = [];
    let play_pic = [];
    let counters = {
        '夸克': 1,
        '百度': 1,
        'UC': 1
    };
    let successCount_total = 0;

    let allLines = [];
    for (let r of results) {
        if (r) {
            allLines.push(r);
        }
    }

    if (allLines.length) {
        allLines.sort((a, b) => {
            let aIdx = lineOrder.findIndex(w => w === a.type);
            let bIdx = lineOrder.findIndex(w => w === b.type);
            return (aIdx === -1 ? 999 : aIdx) - (bIdx === -1 ? 999 : bIdx);
        });
    }

    for (let r of allLines) {
        if (r) {
            let idx = counters[r.type]++;
            play_from.push(`${r.type}#${idx}`);
            play_url.push(r.url);
            play_pic.push(r.imgs);
            successCount_total++;
        }
    }

    const validSourceCount = play_from.length;

    if (play_from.length === 0) {
        play_from.push('网盘');
        play_url.push('分享链接失效$没有找到');
        play_pic.push('');
    }

    let firstLink = shareUrls[0];
    let firstType = firstLink?.type || 'unknown';
    let typeInfo = typeMap[firstType] || {
        icon: defaultImg
    };
    let vod_pic = coverImage ? proxyImage(coverImage) : typeInfo.icon;

    let failedDetails = [];
    for (const [pan, stats] of Object.entries(parseStats)) {
        if (stats.failed > 0) {
            failedDetails.push(`${pan}(${stats.failed}个失败): ${stats.failedUrls.join(', ')}`);
        }
    }
    const failedText = failedDetails.length > 0 ? `\n${failedDetails.join('\n')}` : '';

    logTime(start, "详情完成");

    const remarkText = validSourceCount > 0 ? `${validSourceCount}个有效源` : `${totalLinks}个链接(全部解析失败)`;

    return JSON.stringify({
        list: [{
            vod_id: id,
            vod_name: vod_name,
            vod_pic: vod_pic,
            vod_content: `共找到 ${totalLinks} 个网盘链接，成功解析 ${successCount_total} 个网盘源${failedText}`,
            vod_remarks: remarkText,
            vod_play_from: play_from.join('$$$'),
            vod_play_url: play_url.join('$$$'),
            vod_play_pic: play_pic.join('$$$'),
            vod_play_pic_ratio: 1.0
        }]
    });
}

async function search(wd, quick, pg) {
    let page = pg || 1;
    console.log(`【${siteName}】搜索参数: wd=${wd}, quick=${quick}, pg=${page}`);

    let panTypesList = panTypes.split(',');
    let searchUrl = buildSearchUrl(wd, page);

    let searchHeaders = {
        "User-Agent": headers["User-Agent"],
        "Accept": headers["Accept"],
        "Content-Type": headers["Content-Type"],
        "Referer": `${apiHost}/`
    };

    let response = await request(searchUrl, {
        headers: searchHeaders,
        timeout: 15000
    });
    let list = [];

    if (response) {
        try {
            let jsonData = JSON.parse(response);
            if (jsonData.code === 0 && jsonData.data) {
                let results = jsonData.data.results || [];
                log(logLevel.info, '搜索', `API返回结果总数: ${results.length}条`);

                let allItems = [];
                let seenUniqueIds = new Set();
                let keywordMatchCount = 0;
                let linkExceedCount = 0;
                let noValidLinkCount = 0;
                let duplicateCount = 0;
                let linkDedupeCount = 0;

                for (let item of results) {
                    let title = item.title || '';
                    if (!title) continue;

                    let uniqueId = item.unique_id || '';
                    if (uniqueId && seenUniqueIds.has(uniqueId)) {
                        duplicateCount++;
                        continue;
                    }
                    if (uniqueId) {
                        seenUniqueIds.add(uniqueId);
                    }

                    if (!new RegExp(wd, "i").test(title)) {
                        continue;
                    }
                    keywordMatchCount++;

                    let links = item.links || [];
                    if (links.length === 0) continue;

                    const seenUrls = new Set();
                    let uniqueLinks = [];
                    for (let link of links) {
                        const urlKey = link.url;
                        if (!seenUrls.has(urlKey)) {
                            seenUrls.add(urlKey);
                            uniqueLinks.push(link);
                        } else {
                            linkDedupeCount++;
                        }
                    }
                    links = uniqueLinks;

                    let filteredLinks = links.filter(link => {
                        let linkType = (link.type || '').toLowerCase();
                        return panTypesList.includes(linkType);
                    });

                    if (filteredLinks.length > maxLinksPerItem) {
                        linkExceedCount++;
                        continue;
                    }

                    if (filteredLinks.length === 0) {
                        noValidLinkCount++;
                        continue;
                    }

                    let images = item.images || [];
                    let coverImage = images.length > 0 ? images[0] : '';
                    if (coverImage) {
                        coverImage = proxyImage(coverImage);
                    }
                    let datetime = item.datetime || '';
                    let content = item.content || '';

                    let detailData = {
                        title: title,
                        links: filteredLinks.map(l => ({
                            url: l.url,
                            type: l.type,
                            password: l.password || ''
                        })),
                        coverImage: coverImage
                    };
                    let detailId = JSON.stringify(detailData);

                    let firstLink = filteredLinks[0];
                    let typeInfo = typeMap[firstLink.type] || {
                        icon: defaultImg,
                        name: '网盘'
                    };
                    let icon = typeInfo.icon;

                    let typeSet = new Set();
                    filteredLinks.forEach(l => {
                        let info = typeMap[l.type];
                        if (info) typeSet.add(info.name);
                    });
                    let panTypesStr = Array.from(typeSet).join('、');
                    let remark = `${filteredLinks.length}个源 | ${panTypesStr}`;

                    let timeStr = '';
                    if (datetime && datetime !== '0001-01-01T00:00:00Z') {
                        timeStr = `📅 时间: ${datetime.substring(0, 10)}\n`;
                    }
                    let contentText = content.replace(/<[^>]*>/g, '').substring(0, 300);
                    let vodContent = (timeStr ? timeStr + '\n' : '') + (contentText || '暂无描述');

                    allItems.push({
                        vod_id: detailId,
                        vod_name: title.length > 80 ? title.substring(0, 80) + '...' : title,
                        vod_pic: coverImage || icon,
                        vod_content: vodContent,
                        vod_remarks: remark,
                        linkCount: filteredLinks.length,
                        hasImage: !!coverImage
                    });
                }

                log(logLevel.info, '搜索', `过滤统计: 重复ID=${duplicateCount}, 关键词匹配=${keywordMatchCount}, 链接去重=${linkDedupeCount}`);
                log(logLevel.info, '搜索', `过滤统计: 链接过多=${linkExceedCount}(>${maxLinksPerItem}), 无有效链接=${noValidLinkCount}`);
                log(logLevel.info, '搜索', `过滤后条目: ${allItems.length}条`);

                log(logLevel.info, '搜索', `限制配置: 最大结果数=${maxResults}, 最大翻页数=${maxPages}, 每项最大链接数=${maxLinksPerItem}`);
                allItems.sort((a, b) => {
                    if (a.linkCount !== b.linkCount) {
                        return b.linkCount - a.linkCount;
                    }
                    return (a.hasImage === b.hasImage) ? 0 : (a.hasImage ? -1 : 1);
                });

                let beforeLimit = allItems.length;
                list = allItems.slice(0, maxResults);
                log(logLevel.info, '搜索', `结果限制: 排序前=${beforeLimit}条, 取前${maxResults}条, 最终=${list.length}条`);
            }
        } catch (e) {
            console.error(`【${siteName}】解析搜索响应失败: ${e.message}`);
        }
    }

    log(logLevel.info, '搜索', `返回结果: ${list.length} 条`);
    return JSON.stringify({
        page: page,
        pagecount: 1,
        limit: list.length,
        total: list.length,
        list: list
    });
}

async function play(flag, id) {
    let ids = id.split('*');
    let urls = [];

    const addUrl = (name, u) => {
        if (u) {
            let finalUrl = u;
            if (enableProxy && proxyUrl) finalUrl = proxyUrl + encodeURIComponent(u);
            urls.push(name, finalUrl + `&thread=${downloadThreads}`);
        }
    };

    if (flag.startsWith('夸克')) {
        if (!Quark.cookie || Quark.cookie.length === 0) {
            return JSON.stringify({
                parse: 0,
                msg: `夸克: 没有获取到cookie`,
                header: headers
            });
        }
        if (ids.length >= 4) {
            let [shareId, stoken, fid, share_fid_token] = ids;
            let header = {
                'User-Agent': headers['User-Agent'],
                'origin': 'https://pan.quark.cn',
                'referer': 'https://pan.quark.cn/',
                'Cookie': Quark.cookie
            };

            if (quarkInfinite) {
                const tokenUrls = await Quark.getUrl(shareId, stoken, fid, share_fid_token);
                tokenUrls?.forEach(item => {
                    if (item?.url) addUrl("无限" + (item.name || ''), item.url);
                });
            }

            let shouldTransfer = quarkTransfer;
            if (quarkInfinite != 1 && quarkOrig != 1 && quarkTransfer != 1) shouldTransfer = 1;

            if (shouldTransfer == 1) {
                if (quarkOrig) {
                    let down = await Quark.getDownload(shareId, stoken, fid, share_fid_token, true);
                    if (down && down.error) {
                        console.log(`【${siteName}】夸克原画失败: ${down.message}`);
                        return JSON.stringify({
                            parse: 0,
                            msg: `夸克: ${down.message || '未知错误'}`,
                            header: header
                        });
                    }
                    if (down?.download_url) addUrl("原画", down.download_url);
                }

                let trans = await Quark.getLiveTranscoding(shareId, stoken, fid, share_fid_token);
                if (trans?.length) {
                    trans.filter(t => t.accessable).forEach(t => {
                        if (t?.video_info?.url) addUrl(mapResolution(t.resolution), t.video_info.url);
                    });
                }
            }

            if (urls.length) {
                return JSON.stringify({
                    parse: 0,
                    url: urls,
                    header: header
                });
            }
        }
        return JSON.stringify({
            parse: 0,
            msg: `夸克: 获取失败`,
            header: headers
        });
    }

    if (flag.startsWith('百度')) {
        if (!Baidu.cookie || Baidu.cookie.length === 0) {
            return JSON.stringify({
                parse: 0,
                msg: `百度: 没有获取到cookie`,
                header: headers
            });
        }
        if (ids.length >= 5) {
            let [path, uk, shareid, fsid, shareDataStr] = ids;
            let shareData = JSON.parse(shareDataStr);

            let original = await Baidu.getAppShareUrl(path, uk, shareid, fsid, shareData);
            if (original && !original.error) {
                addUrl("原画", original);
            } else {
                console.log(`【${siteName}】百度原画失败: ${original?.message || '无响应'}`);
                return JSON.stringify({
                    parse: 0,
                    msg: `百度: ${original?.message || '获取失败'}`,
                    header: headers
                });
            }

            if (urls.length) {
                return JSON.stringify({
                    parse: 0,
                    url: urls,
                    header: {
                        "User-Agent": 'netdisk;P2SP;2.2.91.136;android-android;'
                    }
                });
            }
        }
        return JSON.stringify({
            parse: 0,
            msg: `百度: 获取失败`,
            header: headers
        });
    }

    if (flag.startsWith('UC')) {
        if (!UC.cookie || UC.cookie.length === 0) {
            return JSON.stringify({
                parse: 0,
                msg: `UC: 没有获取到cookie`,
                header: headers
            });
        }
        if (ids.length >= 4) {
            let [shareId, stoken, fid, share_fid_token] = ids;

            let down = await UC.getDownload(shareId, stoken, fid, share_fid_token, true);
            if (down && down.error) {
                console.log(`【${siteName}】UC原画失败: ${down.message}`);
                return JSON.stringify({
                    parse: 0,
                    msg: `UC: ${down.message || '未知错误'}`,
                    header: headers
                });
            }
            if (down?.length) {
                down.forEach(item => {
                    if (item?.url) addUrl(mapResolution(item.name), item.url);
                });
            }

            if (urls.length) {
                return JSON.stringify({
                    parse: 0,
                    url: urls
                });
            }
        }
        return JSON.stringify({
            parse: 0,
            msg: `UC: 获取失败`,
            header: headers
        });
    }

    return JSON.stringify({
        parse: 0,
        msg: `分享链接无效`,
        header: headers
    });
}

async function proxy(params) {
    return [302, '', '', {
        'Location': params.url
    }];
}

function mapResolution(res) {
    return resMap[res] || res;
}

function formatSize(bytes) {
    let size = typeof bytes === 'string' ? parseInt(bytes, 10) : bytes;
    if (!size || isNaN(size) || size <= 0) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    let i = 0;
    while (size >= 1024 && i < units.length - 1) {
        size /= 1024;
        i++;
    }
    return size.toFixed(2) + ' ' + units[i];
}

function proxyImage(url) {
    if (!url) return '';
    if (enableImage && proxyImgUrl) {
        return proxyImgUrl + encodeURIComponent(url);
    }
    return url;
}

function getConfig(key, configObj, cookieData) {
    if (typeof globalThis !== 'undefined' && globalThis[key] !== undefined) return globalThis[key];
    if (cookieData && cookieData[key] !== undefined) return cookieData[key];
    if (configObj && configObj[key] !== undefined) return configObj[key];
    return null;
}

async function loadConfig(url) {
    try {
        log(logLevel.info, '配置', `加载: ${url}`);
        const res = await req(url, {
            timeout: 10000
        });
        if (res?.content) return JSON.parse(res.content);
    } catch (e) {
        log(logLevel.error, '配置', `失败: ${e.message}`);
    }
    return null;
}

async function syncCookies(configObj) {
    let cookieData = null;
    let cookieUrl = configObj?.cookie || (typeof globalThis !== 'undefined' && globalThis.cookie);

    if (cookieUrl && typeof cookieUrl === 'string' && cookieUrl.startsWith('http')) {
        cookieData = await loadConfig(cookieUrl);
        if (cookieData) log(logLevel.info, 'Cookie', `远程配置加载成功`);
    }

    const getVal = (key, def) => {
        let val = getConfig(key, configObj, cookieData);
        return val !== null ? val : def;
    };

    let qc = getVal('quark_cookie');
    if (qc?.length > 10) {
        Quark.cookie = qc;
        log(logLevel.info, 'Cookie', `夸克已设置`);
    }
    let bc = getVal('baidu_cookie');
    if (bc?.length > 10) {
        Baidu.cookie = bc;
        log(logLevel.info, 'Cookie', `百度已设置`);
    }
    let ucc = getVal('uc_cookie');
    if (ucc?.length > 10) {
        UC.cookie = ucc;
        log(logLevel.info, 'Cookie', `UC已设置`);
    }
    let uct = getVal('uc_token');
    if (uct?.length > 10) {
        UC.token = uct;
        log(logLevel.info, 'Cookie', `UCToken已设置`);
    }

    apiHost = getVal('host', apiHost);

    panTypes = getVal('网盘类型', panTypes);
    maxResults = parseInt(getVal('搜索条数', maxResults)) || 50;
    maxPages = parseInt(getVal('翻页限制', maxPages)) || 3;
    downloadThreads = String(getVal('下载线程', downloadThreads));
    enableProxy = getVal('播放代理', enableProxy) ? 1 : 0;
    quarkOrig = getVal('夸克原画', quarkOrig) ? 1 : 0;
    quarkInfinite = getVal('夸克无限', quarkInfinite) ? 1 : 0;
    quarkTransfer = getVal('夸克转存', quarkTransfer) ? 1 : 0;
    proxyUrl = getVal('播放代理地址', proxyUrl);
    proxyImgUrl = getVal('图片代理地址', proxyImgUrl);

    let lineOrderConfig = getVal('线路排序', null);
    if (lineOrderConfig && Array.isArray(lineOrderConfig)) {
        lineOrder = lineOrderConfig;
    }
}

async function request(url, options, retries = 2) {
    if (!options) {
        options = {
            headers: {
                'user-agent': headers['User-Agent']
            },
            timeout: 15000
        };
    }

    for (let i = 0; i < retries; i++) {
        try {
            const result = await req(url, options);
            if (result?.content) {
                return result.content;
            }
        } catch (e) {
            console.error(`【${siteName}】请求失败 (${i+1}/${retries}): ${url} - ${e.message}`);
            if (i === retries - 1) {
                return null;
            }
        }
    }
    return null;
}

const logLevel = {
    debug: 0,
    info: 1,
    warn: 2,
    error: 3
};

function log(level, tag, msg) {
    if (!debug && level === logLevel.debug) return;
    if (level < logLevel.debug) return;
    const prefix = {
        0: '🔍',
        1: '✅',
        2: '⚠️',
        3: '❌'
    } [level] || '📝';
    console.log(`${prefix}【${siteName}-${tag}】 ${msg}`);
}

function logTime(start, label) {
    if (debug) console.log(`⏱️【${siteName}】${label} 耗时: ${Date.now() - start}ms`);
}

export function __jsEvalReturn() {
    return {
        init,
        home,
        homeVod,
        category,
        detail,
        play,
        search,
        proxy
    };
}