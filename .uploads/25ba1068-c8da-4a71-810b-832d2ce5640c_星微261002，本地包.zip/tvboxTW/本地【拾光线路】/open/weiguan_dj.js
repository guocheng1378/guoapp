/*
@header({
  searchable: 1,
  filterable: 1,
  quickSearch: 1,
  title: '围观短剧',
  lang: 'cat'
})
*/

let siteName = '围观短剧';
let siteKey = '';
let siteType = 0;

let UA = "okhttp/4.9.3";

let rule = {
    host: 'https://api.drama.9ddm.com',
    sessionUrl: '/drama/session/create',
    homeUrl: '/drama/home/newShortVideos',
    tagsUrl: '/drama/home/shortVideoTags',
    searchUrl: '/drama/home/searchV2',
    detailUrl: '/drama/home/shortVideoDetail'
};

const PAGE_SIZE = 20;

/* ================= 纯 JS 数学模块（大数 + SECP256R1 ECDH + HMAC-SHA256 + Base64 + UTF-8） =================
   老壳无 BigInt/fetch，全部十进制字符串大数实现，已用 OpenSSL 交叉验证 */

/* ============ 十进制字符串大数运算（ES5，无 BigInt 依赖） ============ */
/* ============ 十进制大数运算（base 1e7 分组，ES5，无 BigInt 依赖） ============
   字符串进出接口；内部用 7 位十进制分组数字数组，乘法/除法快数十倍 */
var BN_BASE = 10000000; /* 1e7 */
function bnToArr(s) {
    s = String(s);
    var neg = false;
    if (s.charAt(0) === '-') { neg = true; s = s.slice(1); }
    var arr = [];
    var i = s.length;
    while (i > 0) {
        var st = i - 7; if (st < 0) st = 0;
        arr.push(parseInt(s.slice(st, i), 10));
        i = st;
    }
    while (arr.length > 1 && arr[arr.length - 1] === 0) arr.pop();
    if (neg) arr.push(0); /* 负数标记位不可用，改用符号数组 */
    return neg ? { neg: true, v: arr } : { neg: false, v: arr };
}
function bnFromArr(a) {
    var v = a.v.slice();
    while (v.length > 1 && v[v.length - 1] === 0) v.pop();
    if (v.length === 1 && v[0] === 0) return '0';
    var s = String(v[v.length - 1]);
    for (var i = v.length - 2; i >= 0; i--) {
        var seg = String(v[i]);
        while (seg.length < 7) seg = '0' + seg;
        s += seg;
    }
    return (a.neg ? '-' : '') + s;
}
function bnNormalize(s) {
    s = String(s);
    if (s.indexOf('-') === 0) return '0';
    var i = 0;
    while (i < s.length - 1 && s.charAt(i) === '0') i++;
    return s.slice(i);
}
function arrCmpAbs(a, b) {
    var A = a.v, B = b.v;
    while (A.length > 1 && A[A.length-1] === 0) A.pop();
    while (B.length > 1 && B[B.length-1] === 0) B.pop();
    if (A.length !== B.length) return A.length < B.length ? -1 : 1;
    for (var i = A.length - 1; i >= 0; i--) {
        if (A[i] !== B[i]) return A[i] < B[i] ? -1 : 1;
    }
    return 0;
}
function bnCmp(a, b) {
    a = bnNormalize(a); b = bnNormalize(b);
    var na = a.charAt(0) === '-', nb = b.charAt(0) === '-';
    if (na !== nb) return na ? -1 : 1;
    var aa = na ? a.slice(1) : a, bb = nb ? b.slice(1) : b;
    var c = arrCmpAbs(bnToArr(aa), bnToArr(bb));
    return na ? -c : c;
}
function arrAdd(a, b) { /* 均非负 */
    var A = a.v, B = b.v;
    var maxLen = Math.max(A.length, B.length);
    var res = []; var carry = 0;
    for (var i = 0; i < maxLen; i++) {
        var d = (i < A.length ? A[i] : 0) + (i < B.length ? B[i] : 0) + carry;
        if (d >= BN_BASE) { d -= BN_BASE; carry = 1; } else carry = 0;
        res.push(d);
    }
    if (carry) res.push(1);
    return { neg: false, v: res };
}
function arrSub(a, b) { /* a >= b，均非负，返回非负 */
    var A = a.v.slice(), B = b.v;
    var borrow = 0;
    for (var i = 0; i < A.length; i++) {
        var d = A[i] - (i < B.length ? B[i] : 0) - borrow;
        if (d < 0) { d += BN_BASE; borrow = 1; } else borrow = 0;
        A[i] = d;
    }
    return { neg: false, v: A };
}
function arrMul(a, b) {
    var A = a.v, B = b.v;
    var res = new Array(A.length + B.length + 1);
    for (var k = 0; k < res.length; k++) res[k] = 0;
    for (var i = 0; i < A.length; i++) {
        if (A[i] === 0) continue;
        for (var j = 0; j < B.length; j++) {
            if (B[j] === 0) continue;
            var pos = i + j;
            res[pos] += A[i] * B[j];
            if (res[pos] >= BN_BASE) {
                res[pos + 1] += Math.floor(res[pos] / BN_BASE);
                res[pos] %= BN_BASE;
            }
        }
    }
    /* 收尾进位 */
    for (var k2 = 0; k2 < res.length - 1; k2++) {
        if (res[k2] >= BN_BASE) {
            res[k2 + 1] += Math.floor(res[k2] / BN_BASE);
            res[k2] %= BN_BASE;
        }
    }
    return { neg: false, v: res };
}
function arrCmpGtEq(a, b) { return arrCmpAbs(a, b) >= 0; }
function bnAdd(a, b) {
    a = String(a); b = String(b);
    var na = a.charAt(0) === '-', nb = b.charAt(0) === '-';
    var A = bnToArr(na ? a.slice(1) : a), B = bnToArr(nb ? b.slice(1) : b);
    if (!na && !nb) return bnFromArr(arrAdd(A, B));
    if (na && nb) return bnFromArr({ neg: true, v: arrAdd(A, B).v });
    /* 异号：大减小 */
    var c = arrCmpAbs(A, B);
    if (c === 0) return '0';
    if (c > 0) return bnFromArr({ neg: na, v: arrSub(A, B).v });
    return bnFromArr({ neg: nb, v: arrSub(B, A).v });
}
function bnSub(a, b) {
    a = String(a); b = String(b);
    var na = a.charAt(0) === '-', nb = b.charAt(0) === '-';
    var A = bnToArr(na ? a.slice(1) : a), B = bnToArr(nb ? b.slice(1) : b);
    /* a - b = a + (-b)，调 bnAdd 处理符号 */
    var bNeg = nb ? '' : '-';
    return bnAdd(na ? '-' + a.slice(1) : a, bNeg + (nb ? b.slice(1) : b));
}
function bnMul(a, b) {
    a = String(a); b = String(b);
    var na = a.charAt(0) === '-', nb = b.charAt(0) === '-';
    var A = bnToArr(na ? a.slice(1) : a), B = bnToArr(nb ? b.slice(1) : b);
    var r = arrMul(A, B);
    r.neg = na !== nb;
    return bnFromArr(r);
}
function arrCmpGERaw(A, B) { /* 裸数组比较 A >= B（低位在前，均去尾部零后） */
    var la = A.length, lb = B.length;
    while (la > 1 && A[la-1] === 0) la--;
    while (lb > 1 && B[lb-1] === 0) lb--;
    if (la !== lb) return la > lb;
    for (var i = la - 1; i >= 0; i--) {
        if (A[i] !== B[i]) return A[i] > B[i];
    }
    return true;
}
function arrSubInPlaceRaw(A, B) { /* A -= B（原地），调用前保证 A >= B */
    var borrow = 0;
    for (var i = 0; i < A.length; i++) {
        var d = A[i] - (i < B.length ? B[i] : 0) - borrow;
        if (d < 0) { d += BN_BASE; borrow = 1; } else borrow = 0;
        A[i] = d;
    }
    return A;
}
function bnDivMod(a, b) { /* a / b, b > 0, 十进制位级长除法（商逐位 0-9），返回 [q, r] */
    a = String(a); b = String(b);
    if (a.charAt(0) === '-') return ['0', '0'];
    var aStr = a;
    while (aStr.length > 1 && aStr.charAt(0) === '0') aStr = aStr.slice(1);
    var B = bnToArr(b).v;
    while (B.length > 1 && B[B.length - 1] === 0) B.pop();
    var q = '';
    var cur = [0];
    for (var i = 0; i < aStr.length; i++) {
        var d = aStr.charCodeAt(i) - 48;
        var carry = d;
        for (var j = 0; j < cur.length; j++) {
            var v = cur[j] * 10 + carry;
            cur[j] = v % BN_BASE;
            carry = Math.floor(v / BN_BASE);
        }
        if (carry > 0) cur.push(carry);
        var digit = 0;
        while (arrCmpGERaw(cur, B)) {
            cur = arrSubInPlaceRaw(cur, B);
            digit++;
        }
        q += String(digit);
    }
    var qi = 0;
    while (qi < q.length - 1 && q.charAt(qi) === '0') qi++;
    return [q.slice(qi), bnFromArr({ neg: false, v: cur })];
}
function bnMod(a, b) { return bnDivMod(a, b)[1]; }
function bnModPow(base, exp, mod) {
    /* 平方-乘：exp 为十进制字符串 */
    base = bnMod(base, mod);
    var result = '1';
    if (bnCmp(exp, '0') === 0) return result;
    var e = String(exp);
    var na = e.charAt(0) === '-';
    if (na) return '0';
    var bits = '';
    while (bnCmp(e, '0') > 0) {
        var dm = bnDivMod(e, '2');
        bits = dm[1] + bits;
        e = dm[0];
    }
    for (var i = 0; i < bits.length; i++) {
        result = bnMod(bnMul(result, result), mod);
        if (bits.charAt(i) === '1') result = bnMod(bnMul(result, base), mod);
    }
    return result;
}
/* 十六进制 <-> 十进制 */
function hexToDec(hex) {
    hex = String(hex).replace(/^0x/i, '').toLowerCase();
    var dec = '0';
    for (var i = 0; i < hex.length; i++) {
        dec = bnAdd(bnMul(dec, '16'), String(parseInt(hex.charAt(i), 16)));
    }
    return dec;
}
function decToHex(dec) {
    dec = bnNormalize(dec);
    if (dec === '0') return '0';
    var hex = '';
    while (bnCmp(dec, '0') > 0) {
        var dm = bnDivMod(dec, '16');
        hex = '0123456789abcdef'.charAt(parseInt(dm[1], 10)) + hex;
        dec = dm[0];
    }
    return hex;
}

/* ============ SECP256R1 域参数 ============ */
var EC_P = hexToDec('FFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFF');
var EC_A = hexToDec('FFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFC');
var EC_B = hexToDec('5AC635D8AA3A93E7B3EBBD55769886BC651D06B0CC53B0F63BCE3C3E27D2604B');
var EC_GX = hexToDec('6B17D1F2E12C4247F8BCE6E563A440F277037D812DEB33A0F4A13945D898C296');
var EC_GY = hexToDec('4FE342E2FE1A7F9B8EE7EB4A7C0F9E162BCE33576B315ECECBB6406837BF51F5');

function ecAddMod(a, b) { return bnMod(bnAdd(a, b), EC_P); }
function ecSubMod(a, b) {
    if (bnCmp(a, b) < 0) return bnSub(bnAdd(a, EC_P), b); /* a-b+p */
    return bnSub(a, b);
}
function ecMulMod(a, b) { return bnMod(bnMul(a, b), EC_P); }

/* 雅可比坐标点：{x,y,z} */
function ecToJacob(x, y) { return { x: x, y: y, z: '1' }; }
function ecDbl(p) {
    if (bnCmp(p.y, '0') === 0) return { x: '0', y: '0', z: '0' };
    var xx = ecMulMod(p.x, p.x);
    var yy = ecMulMod(p.y, p.y);
    var yyyy = ecMulMod(yy, yy);
    var zz = ecMulMod(p.z, p.z);
    /* S = 2*((X1+YY)^2 - XX - YYYY) */
    var x1yy = ecAddMod(p.x, yy);
    var term = ecSubMod(ecMulMod(x1yy, x1yy), ecAddMod(xx, yyyy));
    var s = ecAddMod(term, term);
    /* M = 3*XX + a*ZZ^2 = 3*(XX - ZZ^2)  (a=-3) */
    var zz2 = ecMulMod(zz, zz);
    var m = ecMulMod(ecSubMod(xx, zz2), '3');
    var t = ecSubMod(ecMulMod(m, m), ecAddMod(s, s));
    var x3 = t;
    var y3 = ecSubMod(ecMulMod(m, ecSubMod(s, t)), ecMulMod('8', yyyy));
    /* Z3 = (Y1+Z1)^2 - YY - ZZ */
    var y1z1 = ecAddMod(p.y, p.z);
    var z3 = ecSubMod(ecSubMod(ecMulMod(y1z1, y1z1), yy), zz);
    return { x: x3, y: y3, z: z3 };
}
function ecAdd(p, q) {
    if (bnCmp(p.z, '0') === 0) return { x: q.x, y: q.y, z: q.z };
    if (bnCmp(q.z, '0') === 0) return { x: p.x, y: p.y, z: p.z };
    var z1z1 = ecMulMod(p.z, p.z);
    var z2z2 = ecMulMod(q.z, q.z);
    var u1 = ecMulMod(p.x, z2z2);
    var u2 = ecMulMod(q.x, z1z1);
    var s1 = ecMulMod(p.y, ecMulMod(q.z, z2z2));
    var s2 = ecMulMod(q.y, ecMulMod(p.z, z1z1));
    var h = ecSubMod(u2, u1);
    var r = ecSubMod(s2, s1);
    if (bnCmp(h, '0') === 0) {
        if (bnCmp(r, '0') === 0) return ecDbl(p);
        return { x: '0', y: '0', z: '0' };
    }
    var hh = ecMulMod(h, h);
    var hhh = ecMulMod(h, hh);
    var v = ecMulMod(u1, hh);
    var x3 = ecSubMod(ecSubMod(ecMulMod(r, r), hhh), ecAddMod(v, v));
    var y3 = ecSubMod(ecMulMod(r, ecSubMod(v, x3)), ecMulMod(s1, hhh));
    var z3 = ecMulMod(ecMulMod(p.z, q.z), h);
    return { x: x3, y: y3, z: z3 };
}
function ecMul(kHex, px, py) {
    /* k: 十六进制字符串（私钥/标量），点乘，4-bit 窗口 */
    var bits = '';
    var k = hexToDec(kHex);
    while (bnCmp(k, '0') > 0) {
        var dm = bnDivMod(k, '2');
        bits = dm[1] + bits;
        k = dm[0];
    }
    if (bits.length === 0) return { x: '0', y: '0', z: '0' };
    while (bits.length % 4 !== 0) bits = '0' + bits;
    var G = ecToJacob(px, py);
    var tbl = [ { x: '0', y: '0', z: '0' }, G ];
    for (var m = 2; m <= 15; m++) tbl.push(ecAdd(tbl[m - 1], G));
    var Q = { x: '0', y: '0', z: '0' };
    for (var i = 0; i < bits.length; i += 4) {
        Q = ecDbl(Q); Q = ecDbl(Q); Q = ecDbl(Q); Q = ecDbl(Q);
        var w = (bits.charCodeAt(i) - 48) * 8 + (bits.charCodeAt(i + 1) - 48) * 4 +
                (bits.charCodeAt(i + 2) - 48) * 2 + (bits.charCodeAt(i + 3) - 48);
        if (w > 0) Q = ecAdd(Q, tbl[w]);
    }
    return Q;
}
function ecModInv(a) {
    /* 费马小定理 a^(p-2) mod p */
    var e = bnSub(EC_P, '2');
    return bnModPow(a, e, EC_P);
}
function ecPointToAffine(P) {
    if (bnCmp(P.z, '0') === 0) return null; /* 无穷远点 */
    var zi = ecModInv(P.z);
    var zi2 = ecMulMod(zi, zi);
    var zi3 = ecMulMod(zi2, zi);
    return {
        x: ecMulMod(P.x, zi2),
        y: ecMulMod(P.y, zi3)
    };
}

/* ============ 字节 / 十六进制 / Base64 工具 ============ */
function hexToBytes(hex) {
    hex = String(hex).toLowerCase();
    var out = [];
    for (var i = 0; i < hex.length; i += 2) {
        out.push(parseInt(hex.substr(i, 2), 16));
    }
    return out;
}
function bytesToHex(bytes) {
    var out = '';
    for (var i = 0; i < bytes.length; i++) {
        var h = bytes[i].toString(16);
        out += h.length < 2 ? '0' + h : h;
    }
    return out;
}
function decToHexBytes(dec, padLen) {
    var hex = decToHex(dec);
    while (hex.length < padLen * 2) hex = '0' + hex;
    return hexToBytes(hex);
}
function b64EncodeBytes(bytes) {
    var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    var out = '', i;
    for (i = 0; i + 2 < bytes.length; i += 3) {
        var n = (bytes[i] << 16) | (bytes[i + 1] << 8) | bytes[i + 2];
        out += chars.charAt((n >> 18) & 63) + chars.charAt((n >> 12) & 63) + chars.charAt((n >> 6) & 63) + chars.charAt(n & 63);
    }
    if (i === bytes.length - 1) {
        var n2 = bytes[i] << 16;
        out += chars.charAt((n2 >> 18) & 63) + chars.charAt((n2 >> 12) & 63) + '==';
    } else if (i === bytes.length - 2) {
        var n3 = (bytes[i] << 16) | (bytes[i + 1] << 8);
        out += chars.charAt((n3 >> 18) & 63) + chars.charAt((n3 >> 12) & 63) + chars.charAt((n3 >> 6) & 63) + '=';
    }
    return out;
}

/* ============ SHA-256 / HMAC-SHA256 ============ */
var SHA_K = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
];
function sha256Bytes(msg) {
    function rotr(x, n) { return ((x >>> n) | (x << (32 - n))) >>> 0; }
    var h = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19];
    var ml = msg.length * 8;
    var withOne = msg.slice();
    withOne.push(0x80);
    while (withOne.length % 64 !== 56) withOne.push(0);
    withOne.push(0, 0, 0, 0, 0, 0, 0, 0);
    var mlHi = Math.floor(ml / 0x100000000), mlLo = ml >>> 0;
    withOne[withOne.length - 8] = (mlHi >>> 24) & 0xff;
    withOne[withOne.length - 7] = (mlHi >>> 16) & 0xff;
    withOne[withOne.length - 6] = (mlHi >>> 8) & 0xff;
    withOne[withOne.length - 5] = mlHi & 0xff;
    withOne[withOne.length - 4] = (mlLo >>> 24) & 0xff;
    withOne[withOne.length - 3] = (mlLo >>> 16) & 0xff;
    withOne[withOne.length - 2] = (mlLo >>> 8) & 0xff;
    withOne[withOne.length - 1] = mlLo & 0xff;
    for (var i = 0; i < withOne.length; i += 64) {
        var w = [];
        for (var t = 0; t < 16; t++) {
            var o = i + t * 4;
            w[t] = ((withOne[o] << 24) | (withOne[o + 1] << 16) | (withOne[o + 2] << 8) | withOne[o + 3]) >>> 0;
        }
        for (t = 16; t < 64; t++) {
            var s0 = rotr(w[t - 15], 7) ^ rotr(w[t - 15], 18) ^ (w[t - 15] >>> 3);
            var s1 = rotr(w[t - 2], 17) ^ rotr(w[t - 2], 19) ^ (w[t - 2] >>> 10);
            w[t] = (w[t - 16] + s0 + w[t - 7] + s1) >>> 0;
        }
        var a = h[0], b = h[1], c = h[2], d = h[3], e = h[4], f = h[5], g = h[6], hh = h[7];
        for (t = 0; t < 64; t++) {
            var S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
            var ch = (e & f) ^ ((~e) & g);
            var temp1 = (hh + S1 + ch + SHA_K[t] + w[t]) >>> 0;
            var S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
            var maj = (a & b) ^ (a & c) ^ (b & c);
            var temp2 = (S0 + maj) >>> 0;
            hh = g; g = f; f = e; e = (d + temp1) >>> 0; d = c; c = b; b = a;
            a = (temp1 + temp2) >>> 0;
        }
        h[0] = (h[0] + a) >>> 0; h[1] = (h[1] + b) >>> 0; h[2] = (h[2] + c) >>> 0; h[3] = (h[3] + d) >>> 0;
        h[4] = (h[4] + e) >>> 0; h[5] = (h[5] + f) >>> 0; h[6] = (h[6] + g) >>> 0; h[7] = (h[7] + hh) >>> 0;
    }
    var out = [];
    for (var i2 = 0; i2 < 8; i2++) {
        out.push((h[i2] >>> 24) & 0xff, (h[i2] >>> 16) & 0xff, (h[i2] >>> 8) & 0xff, h[i2] & 0xff);
    }
    return out;
}
function hmacSha256Hex(keyBytes, msgBytes) {
    var block = 64, ipad = [], opad = [];
    var key = keyBytes.slice();
    if (key.length > block) key = sha256Bytes(key);
    for (var i = 0; i < block; i++) {
        var kb = i < key.length ? key[i] : 0;
        ipad.push(kb ^ 0x36);
        opad.push(kb ^ 0x5c);
    }
    var inner = sha256Bytes(ipad.concat(msgBytes));
    var outer = sha256Bytes(opad.concat(inner));
    return bytesToHex(outer);
}

/* ============ ECDH： clientPrivHex(64hex) * serverPubKey(b64 的 SPKI DER 或裸点) -> 32字节共享秘密hex ============ */
function parsePubPoint(raw) {
    /* 兼容：SPKI DER (0x30 ... 03 42 00 04||X||Y)，65字节裸点(04||X||Y)，或 64 字节 X||Y */
    if (raw.length === 65 && raw[0] === 4) return { x: raw.slice(1, 33), y: raw.slice(33, 65) };
    if (raw.length === 64) return { x: raw.slice(0, 32), y: raw.slice(32, 64) };
    if (raw.length > 65) {
        /* SPKI DER：从尾部找 04||X||Y */
        for (var i = raw.length - 65; i >= 0; i--) {
            if (raw[i] === 4) return { x: raw.slice(i + 1, i + 33), y: raw.slice(i + 33, i + 65) };
        }
    }
    return null;
}
function ecdhSharedHex(clientPrivHex, serverPubSpkiB64) {
    var raw = b64DecodeToBytes(serverPubSpkiB64);
    var pt = parsePubPoint(raw);
    if (!pt) return '';
    var P = ecMul(clientPrivHex, hexToDec(bytesToHex(pt.x)), hexToDec(bytesToHex(pt.y)));
    var aff = ecPointToAffine(P);
    if (!aff) return '';
    return bytesToHex(decToHexBytes(aff.x, 32));
}
function b64DecodeToBytes(b64) {
    var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    var map = {};
    for (var i = 0; i < 64; i++) map[chars.charAt(i)] = i;
    b64 = String(b64).replace(/[^A-Za-z0-9+/=]/g, '');
    var out = [];
    var buf = 0, bits = 0;
    for (var j = 0; j < b64.length; j++) {
        if (b64.charAt(j) === '=') break;
        buf = (buf << 6) | (map[b64.charAt(j)] || 0);
        bits += 6;
        if (bits >= 8) {
            bits -= 8;
            out.push((buf >> bits) & 0xff);
        }
    }
    return out;
}

function utf8ToBytes(str) {
    str = String(str);
    var out = [];
    for (var i = 0; i < str.length; i++) {
        var c = str.charCodeAt(i);
        if (c < 0x80) {
            out.push(c);
        } else if (c < 0x800) {
            out.push(0xc0 | (c >> 6), 0x80 | (c & 0x3f));
        } else if (c >= 0xd800 && c < 0xdc00 && i + 1 < str.length) {
            var c2 = str.charCodeAt(i + 1);
            if (c2 >= 0xdc00 && c2 < 0xe000) {
                var cp = 0x10000 + ((c - 0xd800) << 10) + (c2 - 0xdc00);
                out.push(0xf0 | (cp >> 18), 0x80 | ((cp >> 12) & 0x3f), 0x80 | ((cp >> 6) & 0x3f), 0x80 | (cp & 0x3f));
                i++;
            } else out.push(0xe0 | (c >> 12), 0x80 | ((c >> 6) & 0x3f), 0x80 | (c & 0x3f));
        } else if (c >= 0xd800 && c < 0xe000) {
            out.push(0xef, 0xbf, 0xbd);
        } else {
            out.push(0xe0 | (c >> 12), 0x80 | ((c >> 6) & 0x3f), 0x80 | (c & 0x3f));
        }
    }
    return out;
}

var PRESET_KEYS = [
    { priv: "bcba51154a16aad498d94cd95db1a0c6f35182e83f728d679ba7c167b7a2b909", enc: "ezv2mhMG1mNM7mEA+H/W88W84hfkMLVeVVPQUyJtL86DdzwMnwXPCsFI3njbydH5k4W3DQJYx8EIs8AQp03lNgp4eYdRBUtriAsx1yjogQGMujDKdY8UkwWdbPU5zkaZjtHkeyBV8EQesverila6X74g/AHjGTUhLOAYuYRE8NFCBRKF+oPJDlwivZQxPreMHFzY0MzJfzl2GwZx64RN0JoIA73Hsrg3+MrHz3CejXME6eoeAnfy9QFsRj61eYJcUbRPofzQBktr/3Tuw4VD/bOqmcoB4n+JeVmKLBonxkDK0wYQP+iDCdNvy2gRxrt1Nv70zp8WfscfsCiGqCy+mA==" },
    { priv: "fc5f22fd1c09f35a62726924bd72e22b29440736981a1c74a4ee2aad2faf295d", enc: "YIDNwwFtfZFCCgSC/klCCFkZmucnSNAtW75bcbPzzgBdDRRIqoIeSQPztPCzTynaKqDMHFtC7K5PUdGyP4aTEeY52N7+HbF5snFG/SjFtCg/JjEEnSKoL7nOPFnBUBMuIrXTjGcRjkgiVbypJ6iiYhohg/pqH9FhN0UuBQbNpA7enj5mDo3erbz1w/oBhYgdoUB0GLUZwF6e9vasG/aDeg9JvfOahT2bj/BVH4lq0bBSRybE9RtLyUNeIL7CywruoqbPSAKc/wIrFy0cvLz1s7NKha24iALLtt7BuQUr/OpFErFxEuqZF1c9j1GpEunjve11eXjTaZ43Il0fnjbn3A==" },
    { priv: "eb56a2ba90d4a3545bfc5047f834a0d9b5e05255cf737d4f9c2c35ee22e4468d", enc: "PxkPU0Xkk0mf+DI5o6tCXZ7NAllHxXVwCdqmkohOaNK/gu6N1qSvbDMcPg3kh0f28eQzLE7dYxXJuteYMuGWEXiAglJb7qlNnv4DYBVlaRAt3UfQgQmFwH1VXhc5q8+OB32BkdUk9o/ouKBAT4anEmvtiT7jwwqKPw/npIEeyR0ufByYpe1Ac+1m3zH+KMk0JajO/BHLCUb1J8w2pDPiKrUW1KVpDYXV97utbGOYZlIOqh1J9UohOAUFaLXhx6+3q5lnRaHPUbhEsgAC4jGffOn+fc7s1/nEfTkUIZpeu68xEnAF1GqqylGhvbD0U4eJhR97LhYHrCzBD5YUQpkaRA==" }
];

/* ================= 会话管理（App 端签名协议） ================= */

var _sid = '';          // 当前会话 sessionId
var _sKeyHex = '';      // 当前会话 ECDH 共享秘密（32 字节 hex）
var _skIdx = -1;        // 当前使用的预置密钥下标

// 生成 32 位 hex 随机串（nonce / deviceId 后缀）
function randHex(len) {
    var s = '';
    var chars = '0123456789abcdef';
    for (var i = 0; i < len; i++) s += chars.charAt(Math.floor(Math.random() * 16));
    return s;
}

/* 创建新会话：POST /drama/session/create（此接口免签名）
   返回 {ok, sid, sKeyHex} */
async function createSessionOnce(kIdx) {
    var pair = PRESET_KEYS[kIdx];
    var ts = String(Date.now());
    var nonce = randHex(32);
    var deviceId = 'device_' + ts + '_' + randHex(8);
    var q = 'encryptedClientPublicKey=' + encodeURIComponent(pair.enc) +
            '&nonce=' + nonce +
            '&timestamp=' + ts +
            '&deviceId=' + encodeURIComponent(deviceId) +
            '&deviceName=' + encodeURIComponent('Pixel 8') +
            '&osType=1';
    var url = rule.host + rule.sessionUrl + '?' + q;
    var data = await req(url, {
        method: 'POST',
        headers: { 'User-Agent': UA, 'Content-Type': 'application/x-www-form-urlencoded' },
        timeout: 15000
    });
    var content = (data && data.content) || (data && data.data) || data;
    var obj = (typeof content === 'string') ? safeJSONParse(content, null) : content;
    if (!obj || obj.code !== 200 || !obj.data) {
        console.log('【' + siteName + '】会话创建失败 idx=' + kIdx);
        return null;
    }
    var spki = obj.data.serverEphemeralPublicKey;
    var sKeyHex = ecdhSharedHex(pair.priv, spki);
    if (!sKeyHex) {
        console.log('【' + siteName + '】ECDH 失败');
        return null;
    }
    return { sid: obj.data.sessionId, sKeyHex: sKeyHex };
}

/* 确保有可用会话；失败时轮换预置密钥（最多 3 组），单组创建失败立即换下一组 */
async function ensureSession(force) {
    if (!force && _sid && _sKeyHex) return true;
    for (var t = 0; t < 3; t++) {
        _skIdx = (_skIdx + 1) % PRESET_KEYS.length;
        var r = await createSessionOnce(_skIdx);
        if (r && r.sid) {
            _sid = r.sid;
            _sKeyHex = r.sKeyHex;
            console.log('【' + siteName + '】会话就绪 ' + _sid.slice(0, 12) + '... key=' + PRESET_KEYS.length + '组轮换#' + _skIdx);
            return true;
        }
    }
    _sid = '';
    _sKeyHex = '';
    return false;
}

/* 计算签名：params 为 [[k,v],...]（query，含已排序），bodyObj 为 POST JSON 对象
   signStr = 排序(query) + 排序(body) 拼接 k1v1k2v2... + timestamp + nonce
   sign = hex(HmacSHA256(ascii(base64(sessionKey)), utf8(signStr))) */
function buildSign(params, bodyObj) {
    var kv = [];
    var i;
    for (i = 0; i < params.length; i++) kv.push(params[i]);
    if (bodyObj) {
        var keys = Object.keys(bodyObj).sort();
        for (i = 0; i < keys.length; i++) kv.push([keys[i], String(bodyObj[keys[i]])]);
    }
    /* query 部分按 key 排序（调用方保证已排），body 部分已排 —— 与实测一致：query 排序在前、body 排序在后拼接 */
    var p = params.slice().sort(function (a, b) { return a[0] < b[0] ? -1 : (a[0] > b[0] ? 1 : 0); });
    var b = bodyObj ? keysOf(bodyObj) : [];
    var qs = '';
    for (i = 0; i < p.length; i++) qs += p[i][0] + String(p[i][1]);
    for (i = 0; i < b.length; i++) qs += b[i] + String(bodyObj[b[i]]);
    var ts = String(Date.now());
    var nonce = randHex(32);
    var signStr = qs + ts + nonce;
    var keyB64 = b64EncodeBytes(hexToBytes(_sKeyHex));
    var keyBytes = asciiToBytes(keyB64);
    var signHex = hmacSha256Hex(keyBytes, utf8ToBytes(signStr));
    return {
        'X-Session-Id': _sid,
        'X-Sign': signHex,
        'X-Timestamp': ts,
        'X-Nonce': nonce
    };
}

function keysOf(o) {
    var k = [];
    for (var key in o) {
        if (Object.prototype.hasOwnProperty.call(o, key)) k.push(key);
    }
    return k.sort();
}

function asciiToBytes(s) {
    var out = [];
    for (var i = 0; i < s.length; i++) out.push(s.charCodeAt(i) & 0xff);
    return out;
}

// 通用请求：自动附加签名头（sessionUrl 除外）；403 时重建会话重试一次
async function request(path, params, bodyObj) {
    if (!_sid || !_sKeyHex) {
        var ok = await ensureSession(false);
        if (!ok) return null;
    }
    var signHeaders = buildSign(params || [], bodyObj);
    var url = rule.host + path + (params && params.length ? '?' + urlEncodePairs(params) : '');
    var headers = {
        'User-Agent': UA,
        'X-Session-Id': signHeaders['X-Session-Id'],
        'X-Sign': signHeaders['X-Sign'],
        'X-Timestamp': signHeaders['X-Timestamp'],
        'X-Nonce': signHeaders['X-Nonce']
    };
    var dataStr = '';
    var dataObj = null;
    if (bodyObj) {
        headers['Content-Type'] = 'application/json;charset=UTF-8';
        dataStr = JSON.stringify(bodyObj);
        dataObj = bodyObj; /* 关键：OK 壳(FongMi 快鸭)的 Req.data 是 Gson JsonElement，传字符串会被当 JsonPrimitive，
            toString() 序列化时带引号转义成非法 JSON（Connect.getJsonBody 走 data 分支优先于 body）；
            传对象则 Gson 序列化为规范 JSON，body 字符串仅供请求体原样兜底。 */
    }
    var data = await req(url, {
        method: bodyObj ? 'POST' : 'GET',
        headers: headers,
        body: dataStr,
        data: dataObj,
        timeout: 15000
    });
    var content = (data && data.content) || (data && data.data) || data;
    var obj = (typeof content === 'string') ? safeJSONParse(content, null) : content;
    if (obj && obj.code === 403) {
        console.log('【' + siteName + '】会话失效，重建');
        _sid = ''; _sKeyHex = '';
        var ok2 = await ensureSession(false);
        if (!ok2) return null;
        var signHeaders2 = buildSign(params || [], bodyObj);
        var headers2 = {
            'User-Agent': UA,
            'X-Session-Id': signHeaders2['X-Session-Id'],
            'X-Sign': signHeaders2['X-Sign'],
            'X-Timestamp': signHeaders2['X-Timestamp'],
            'X-Nonce': signHeaders2['X-Nonce']
        };
        var dataStr2 = '';
        var dataObj2 = null;
        if (bodyObj) { headers2['Content-Type'] = 'application/json;charset=UTF-8'; dataStr2 = JSON.stringify(bodyObj); dataObj2 = bodyObj; }
        var retry = await req(url, { method: bodyObj ? 'POST' : 'GET', headers: headers2, body: dataStr2, data: dataObj2, timeout: 15000 });
        var rc = (retry && retry.content) || (retry && retry.data) || retry;
        return (typeof rc === 'string') ? safeJSONParse(rc, null) : rc;
    }
    return obj;
}

function urlEncodePairs(pairs) {
    var parts = [];
    for (var i = 0; i < pairs.length; i++) {
        parts.push(encodeURIComponent(pairs[i][0]) + '=' + encodeURIComponent(String(pairs[i][1])));
    }
    return parts.join('&');
}

/* ================= 通用工具 ================= */

function init(cfg) {
    try {
        siteName = (cfg.skey && cfg.skey.split('_')[1]) || (cfg.key && cfg.key.split('_')[1]) || cfg.skey || cfg.key || '围观短剧';
        siteKey = cfg.skey;
        siteType = cfg.stype;
        console.log('【' + siteName + '】初始化完成');
    } catch (e) {
        console.log('【' + siteName + '】初始化失败: ' + e.message);
    }
}

function safeJSONParse(str, defaultValue) {
    var def = defaultValue === undefined ? {} : defaultValue;
    if (!str) return def;
    if (typeof str === 'object') return str;
    try {
        return JSON.parse(str);
    } catch (e) {
        return def;
    }
}

function pickPoster(it) {
    return it.vertPoster || it.horzPoster || it.vertMidPoster || '';
}

/* ================= TVBox 接口 ================= */

async function home() {
    var classes = [{ type_name: '全部', type_id: '全部' }];
    var filters = { '全部': [] };

    var data = await request(rule.tagsUrl, [], null);
    if (data && data.code === 200) {
        var audiences = data.audiences || [];
        var tags = data.tags || [];
        var orders = data.orders || [];
        if (audiences.length === 0 && orders.length === 0) audiences = ['全部'];
        for (var i = 0; i < audiences.length; i++) {
            var audience = audiences[i];
            classes.push({ type_name: audience, type_id: audience });
            filters[audience] = [];
            var tagValues = [{ n: '全部', v: '' }];
            for (var j = 0; j < tags.length; j++) tagValues.push({ n: tags[j], v: tags[j] });
            filters[audience].push({ key: 'tag', name: '标签', value: tagValues });
            var orderValues = [];
            for (var k = 0; k < orders.length; k++) orderValues.push({ n: orders[k], v: orders[k] });
            filters[audience].push({ key: 'order', name: '排序', value: orderValues });
        }
    } else if (!data) {
        classes.push({ type_name: '推荐', type_id: '推荐' });
        filters['推荐'] = [];
    }

    return JSON.stringify({ class: classes, filters: filters });
}

async function homeVod() {
    try {
        var videos = [];
        var data = await request(rule.homeUrl, [['page', 1], ['pageSize', PAGE_SIZE]], null);
        var list = (data && data.data) || [];
        for (var i = 0; i < list.length; i++) {
            var it = list[i];
            if (it && it.oneId) {
                videos.push({
                    vod_id: String(it.oneId),
                    vod_name: it.title || '未知标题',
                    vod_pic: pickPoster(it),
                    vod_remarks: '集数:' + (it.episodeCount || 0),
                    vod_content: it.description || ''
                });
            }
        }
        return JSON.stringify({ list: videos });
    } catch (e) {
        console.log('【' + siteName + '】homeVod失败: ' + e.message);
        return JSON.stringify({ list: [] });
    }
}

async function category(tid, pg, filter, extend) {
    var videos = [];
    var page = pg || 1;
    var tag = (extend && extend.tag) ? extend.tag : ((filter && filter.tag) ? filter.tag : '');
    var order = (extend && extend.order) ? extend.order : ((filter && filter.order) ? filter.order : '');
    var audience = (tid === '全部' || tid === '推荐') ? '' : tid;

    var postData = {
        audience: audience,
        episodeCount: '',
        order: order,
        page: page,
        pageSize: PAGE_SIZE,
        searchWord: '',
        shortPlayType: '',
        subject: tag,
        uid: '0'
    };

    var data = await request(rule.searchUrl, [], postData);
    var list = (data && data.data) || [];
    for (var i = 0; i < list.length; i++) {
        var it = list[i];
        if (it && it.oneId) {
            videos.push({
                vod_id: String(it.oneId),
                vod_name: it.title || '未知标题',
                vod_pic: pickPoster(it),
                vod_remarks: '集数:' + (it.episodeCount || 0),
                vod_content: it.description || '',
                vod_year: it.publishDate || ''
            });
        }
    }

    var hasNext = videos.length >= PAGE_SIZE;
    return JSON.stringify({
        list: videos,
        page: page,
        pagecount: hasNext ? page + 1 : page,
        limit: videos.length,
        total: videos.length
    });
}

/* 详情：App 端一次拉全集（pageSize=1000 实际返回全部集，含三档直链） */
async function detail(id) {
    if (!id) return JSON.stringify({ list: [] });

    var data = await request(rule.detailUrl, [
        ['oneId', id], ['page', 1], ['pageSize', 1000], ['userId', 0], ['queryAll', '0']
    ], null);

    var list = (data && data.data) || [];
    if (!list || list.length === 0) {
        console.log('【' + siteName + '】详情无数据: id=' + id);
        return JSON.stringify({ list: [] });
    }

    var items = list.slice().sort(function (a, b) { return (a.playOrder || 0) - (b.playOrder || 0); });
    var playUrl = '';
    var name = '';
    var poster = '';
    var desc = '';
    for (var i = 0; i < items.length; i++) {
        var ep = items[i];
        var psText = ep.playSetting || '';
        var clarity = {};
        var psObj = safeJSONParse(psText, {});
        if (psObj.super) clarity.超清 = psObj.super;
        if (psObj.high) clarity.高清 = psObj.high;
        if (psObj.normal) clarity.流畅 = psObj.normal;
        if (Object.keys(clarity).length === 0) continue;
        if (!name) name = ep.title || '';
        if (!poster) poster = ep.vertPoster || '';
        var seg = '第' + (ep.playOrder || (i + 1)) + '集$' + encodeURIComponent(JSON.stringify(clarity));
        playUrl = playUrl ? playUrl + '#' + seg : seg;
    }

    if (!playUrl) return JSON.stringify({ list: [] });

    var vod = {
        vod_id: String(id),
        vod_name: name || '未知剧名',
        vod_pic: poster,
        vod_remarks: '共' + items.length + '集',
        vod_content: desc,
        vod_play_from: '围观短剧',
        vod_play_url: playUrl
    };

    return JSON.stringify({ list: [vod] });
}

async function play(flag, id, flags) {
    var info = null;
    if (typeof id === 'object') {
        info = id;
    } else if (typeof id === 'string') {
        var decoded;
        try { decoded = decodeURIComponent(id); } catch (e2) { decoded = id; }
        info = safeJSONParse(decoded, null);
    }

    if (info) {
        var clarityOrder = ['超清', '高清', '流畅'];
        var urls = [];
        for (var i = 0; i < clarityOrder.length; i++) {
            var u = info[clarityOrder[i]];
            if (u && urls.indexOf(u) < 0) {
                urls.push(clarityOrder[i], u);
            }
        }
        if (urls.length > 0) {
            return JSON.stringify({ parse: 0, url: urls });
        }
    }

    if (typeof id === 'string' && id.indexOf('http') === 0) {
        return JSON.stringify({ parse: 0, url: id });
    }

    return JSON.stringify({ parse: 0, url: '', msg: '暂无可用播放地址' });
}

async function search(wd, quick, pg) {
    if (!wd || wd.trim() === '') {
        return JSON.stringify({ list: [], page: 1 });
    }

    var page = pg || 1;
    var postData = {
        audience: '',
        episodeCount: '',
        order: '',
        page: page,
        pageSize: PAGE_SIZE,
        searchWord: wd.trim(),
        shortPlayType: '',
        subject: '',
        uid: '0'
    };

    var data = await request(rule.searchUrl, [], postData);
    var list = (data && data.data) || [];
    var videos = [];
    for (var i = 0; i < list.length; i++) {
        var it = list[i];
        if (it && it.oneId) {
            videos.push({
                vod_id: String(it.oneId),
                vod_name: it.title || '未知标题',
                vod_pic: pickPoster(it),
                vod_remarks: '集数:' + (it.episodeCount || 0),
                vod_content: it.description || '',
                vod_year: it.publishDate || ''
            });
        }
    }

    return JSON.stringify({
        list: videos,
        page: page,
        pagecount: videos.length >= PAGE_SIZE ? page + 1 : page,
        limit: videos.length,
        total: videos.length
    });
}

export function __jsEvalReturn() {
    return {
        init: init,
        home: home,
        homeVod: homeVod,
        category: category,
        detail: detail,
        play: play,
        search: search
    };
}
