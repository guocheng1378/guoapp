import sys
import re
import json
import base64
import html as html_lib
import requests
 
sys.path.append('..')
from base.spider import Spider as BaseSpider
 
 
class Spider(BaseSpider):
    author = "集多"

    def getName(self):
        return "酷狗音乐[集多]"
 
    def init(self, extend=""):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16 like Mac OS X) '
                          'AppleWebKit/605.1.15 (KHTML, like Gecko) '
                          'Version/16 Mobile/15E148 Safari/604.1',
            'Referer': 'https://www.kugou.com/',
            'Origin': 'https://www.kugou.com',
            'Accept-Language': 'zh-CN,zh;q=0.9',
            'Accept': 'application/json, text/plain, */*',
        })
        try:
            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        except Exception:
            pass
        self.log("酷狗音乐初始化完成")
 
    def destroy(self):
        if hasattr(self, 'session'):
            self.session.close()
 
                              
    def homeContent(self, filter):
        classes = [
            {"type_id": "1", "type_name": "🔥 热门榜"},
            {"type_id": "2", "type_name": "🌍 全球榜"},
            {"type_id": "5", "type_name": "🎵 特色榜"},
            {"type_id": "region:zh", "type_name": "🇨🇳 华语"},
            {"type_id": "region:west", "type_name": "🇺🇸 欧美"},
            {"type_id": "region:kr", "type_name": "🇰🇷 韩国"},
            {"type_id": "region:jp", "type_name": "🇯🇵 日本"},
            {"type_id": "plist", "type_name": "歌单"},
            {"type_id": "sarea_1", "type_name": "华语歌手"},
            {"type_id": "sarea_6", "type_name": "韩国歌手"},
            {"type_id": "sarea_5", "type_name": "日本歌手"},
            {"type_id": "sarea_2", "type_name": "欧美歌手"},
            {"type_id": "sarea_4", "type_name": "其他歌手"},
        ]
        return {"class": classes, "filters": {}}

    def homeVideoContent(self):
        return self.categoryContent("1", "1", None, {})

                                 
    def categoryContent(self, tid, pg, filter, ext):
        tid = str(tid)
        if tid.startswith("kugou#"):
            return self._rank_detail(tid, pg)
        if tid == "plist":
            return self._playlist_list("5", pg)
        if tid.startswith("plist_"):
            return self._playlist_song_list(tid, pg)
        if tid.startswith("sarea_"):
            return self._singer_area(tid, pg)
        if tid.startswith("singer_"):
            return self._singer_songs(self._unb64(tid[7:]), pg)
        return self._rank_list(tid, pg)

    def _rank_list(self, tid, pg):
        if pg != "1":
            return {"list": [], "page": pg, "pagecount": 0, "limit": 0, "total": 0}
        rank_list = self._get_rank_list()
        if not rank_list:
            return {"list": [], "page": pg, "pagecount": 0, "limit": 0, "total": 0}

        region_ranks = {
            "region:zh": [("🇨🇳", "内地榜"), ("🇭🇰", "香港地区榜"), ("🇹🇼", "台湾地区榜"), ("🇨🇳", "粤语金曲榜")],
            "region:west": [("🇺🇸", "欧美榜"), ("🇺🇸", "欧美金曲榜"), ("🇺🇸", "美国BillBoard榜"), ("🇬🇧", "英国单曲榜")],
            "region:kr": [("🇰🇷", "韩国榜"), ("🇰🇷", "韩国Melon音乐榜")],
            "region:jp": [("🇯🇵", "日本榜"), ("🇯🇵", "日本公信榜"), ("🇯🇵", "日本SS榜")],
        }
        labels = {}
        if tid in region_ranks:
            labels = {name: flag for flag, name in region_ranks[tid]}
            sub_ranks = [item for item in rank_list if item.get("rankname") in labels]
        else:
            try:
                classify = int(tid)
            except (TypeError, ValueError):
                return {"list": [], "page": pg, "pagecount": 0, "limit": 0, "total": 0}
            sub_ranks = []
            for item in rank_list:
                c = item.get("classify", 0)
                if classify == 1 and c == 1:
                    sub_ranks.append(item)
                elif classify == 2 and c in (2, 4):
                    sub_ranks.append(item)
                elif classify == 5 and c not in (1, 2):
                    sub_ranks.append(item)
                elif classify == c:
                    sub_ranks.append(item)

        video_list = []
        for item in sub_ranks:
            rank_cid = str(item.get("rank_cid", ""))
            rankname = item.get("rankname", "")
            img = (item.get("imgurl") or "").replace("{size}", "400")
            if rank_cid and rankname:
                flag = labels.get(rankname, "🏆")
                video_list.append({
                    "vod_id": f"kugou#{rank_cid}",
                    "vod_name": f"{flag} {rankname}",
                    "vod_pic": img,
                    "vod_remarks": f"{flag} 酷狗榜单",
                    "vod_tag": "folder",
                })
        return {
            "list": video_list,
            "page": pg, "pagecount": 1,
            "limit": len(video_list), "total": len(video_list)
        }

    def _rank_detail(self, tid, pg):
        rank_cid = tid.replace("kugou#", "")
        songs, total = self._get_all_rank_songs(rank_cid)
        if not songs:
            return {"list": [], "page": pg, "pagecount": 0, "limit": 0, "total": 0}
        video_list = []
        for song in songs:
            hash_val = self._extract_best_hash(song)
            if not hash_val:
                continue
            name = self._get_song_name(song)
            singer = self._get_singer_name(song)
            pic = self._get_song_cover(song)
            album_id = self._get_album_id(song)
            mvhash = self._get_mv_hash(song)
            vod_id = f"{hash_val}|{album_id}|{mvhash}|{pic}|rank:{rank_cid}|1"
            video_list.append({
                "vod_id": vod_id,
                "vod_name": name,
                "vod_pic": pic,
                "vod_remarks": singer,
            })
        return {
            "list": video_list,
            "page": pg, "pagecount": 1,
            "limit": len(video_list), "total": total or len(video_list)
        }
 
    def detailContent(self, ids):
        vod_id = str(ids[0] if isinstance(ids, list) else ids)
        rank_id = ""
        rank_page = "1"
        selected_hash = ""
        album_id = ""
        mvhash_from_id = ""
        pic_from_id = ""

        if vod_id.startswith("kugou#"):
            rank_id = vod_id.replace("kugou#", "", 1)
        else:
            parts = vod_id.split("|")
            selected_hash = parts[0] if len(parts) > 0 else ""
            album_id = parts[1] if len(parts) > 1 else ""
            mvhash_from_id = parts[2] if len(parts) > 2 else ""
            pic_from_id = parts[3] if len(parts) > 3 else ""
            if len(parts) > 4 and parts[4].startswith("rank:"):
                rank_id = parts[4].split(":", 1)[1]
                rank_page = parts[5] if len(parts) > 5 and parts[5] else "1"

        tracks = []

        def build_track(song, fallback_hash="", fallback_album="", fallback_mv="", fallback_pic=""):
            try:
                h = self._extract_best_hash(song) or fallback_hash
                if not h:
                    return None
                a = self._get_album_id(song) or fallback_album
                mv = self._get_mv_hash(song) or fallback_mv
                pic = self._get_song_cover(song) or fallback_pic
                name = self._get_song_name(song) or song.get("songName") or song.get("songname") or "未知歌曲"
                singer = self._get_singer_name(song)
                if not singer or singer == "未知歌手":
                    singer = self._extract_singer_from_info(song)
                if not singer:
                    singer = "未知歌手"
                return {"hash": h, "album_id": a, "mvhash": mv, "pic": pic, "name": name, "singer": singer, "quality": self._get_quality_hashes(song, h)}
            except Exception as e:
                self.log(f"构建歌曲失败: {e}")
                return None

        if rank_id:
            songs, _ = self._get_all_rank_songs(rank_id)
            for song in songs:
                track = build_track(song)
                if track:
                    tracks.append(track)

        if not tracks and selected_hash:
            song_info = self._get_song_info(selected_hash, album_id)
            if not song_info:
                song_info = self._get_song_info(selected_hash, "")
            if not song_info:
                song_info = {}
            track = build_track(song_info, selected_hash, album_id, mvhash_from_id, pic_from_id)
            if track:
                tracks.append(track)

        if not tracks:
            return {"list": []}

        for origin_idx, item in enumerate(tracks, 1):
            item["_origin_idx"] = origin_idx

        current = tracks[0]
        current_index = 0
        if selected_hash:
            for idx, item in enumerate(tracks):
                if item.get("hash") == selected_hash or selected_hash in item.get("quality", {}).values():
                    current = item
                    current_index = idx
                    break
        ordered_tracks = tracks
        quality_order = ["无损音质", "高清音质", "标准音质"]

        play_from_list = []
        play_url_list = []
        current_play_hash = ""
        if selected_hash and selected_hash in (current.get("quality") or {}).values():
            current_play_hash = selected_hash
        if not current_play_hash:
            for label in quality_order:
                h = current.get("quality", {}).get(label)
                if h:
                    current_play_hash = h
                    break
        if not current_play_hash:
            current_play_hash = current.get("hash", "")
        if current_play_hash:
            play_from_list.append("当前播放")
            play_url_list.append(f"{self._episode_title(current.get('_origin_idx', 1), current)}${self._pack_play_id(current_play_hash, current.get('album_id', ''), current.get('pic', ''), current.get('name', ''), current.get('singer', ''))}")

        for label in quality_order:
            episodes = []
            seen = set()
            for idx, item in enumerate(ordered_tracks, 1):
                h = item.get("quality", {}).get(label)
                if not h or h in seen:
                    continue
                seen.add(h)
                title = self._episode_title(idx, item)
                play_id = self._pack_play_id(h, item.get("album_id", ""), item.get("pic", ""), item.get("name", ""), item.get("singer", ""))
                episodes.append(f"{title}${play_id}")
            if episodes:
                play_from_list.append(label)
                play_url_list.append("#".join(episodes))

        mv_episodes = []
        seen_mv = set()
        for idx, item in enumerate(ordered_tracks, 1):
            mv = item.get("mvhash") or ""
            if mv and mv not in seen_mv:
                seen_mv.add(mv)
                title = self._episode_title(idx, item)
                mv_episodes.append(f"{title}${self._pack_mv_id(mv, item.get('pic', ''), item.get('name', ''), item.get('singer', ''))}")
        if mv_episodes:
            play_from_list.append("MV")
            play_url_list.append("#".join(mv_episodes))

        if not play_from_list:
            play_from_list.append("标准音质")
            play_url_list.append(f"{self._episode_title(1, current)}${self._pack_play_id(current.get('hash', ''), current.get('album_id', ''), current.get('pic', ''), current.get('name', ''), current.get('singer', ''))}")

        pic = current.get("pic") or pic_from_id
        album = ""
        if selected_hash and not rank_id:
            info = self._get_song_info(selected_hash, album_id) or {}
            album = info.get("albumName") or info.get("album_name") or ""
        video_detail = {
            "vod_id": f"{vod_id}|focus:{selected_hash or current.get('hash', '')}",
            "vod_name": current.get("name") or "酷狗音乐",
            "vod_pic": pic,
            "vod_content": f"歌手：{current.get('singer', '未知歌手')}\n专辑：{album}\n歌曲数：{len(tracks)}",
            "vod_actor": current.get("singer", "未知歌手"),
            "vod_remarks": f"共{len(tracks)}首 | 线路：{' / '.join(play_from_list)}",
            "vod_play_from": "$$$".join(play_from_list),
            "vod_play_url": "$$$".join(play_url_list),
            "vod_play_index": current_index + 1,
            "play_index": current_index,
        }
        return {"list": [video_detail]}
 
    def playerContent(self, flag, id, vipFlags):
        meta = {}
        if flag == "MV":
            url = id
            if "$" in id:
                _, url = id.split("$", 1)
            if url.startswith("mvb:"):
                meta = self._unpack_play_id(url)
                mv_urls = self._get_mv_urls(meta.get("hash", ""))
                url = ""
                for q in ["sq", "rq", "le"]:
                    if q in mv_urls:
                        url = mv_urls[q]
                        break
            elif url.startswith("mv:"):
                mv_urls = self._get_mv_urls(url[3:])
                url = ""
                for q in ["sq", "rq", "le"]:
                    if q in mv_urls:
                        url = mv_urls[q]
                        break
            if not url:
                return {"parse": 0, "url": "", "msg": "MV地址为空"}
            result = {
                "parse": 0, "url": url,
                "header": {
                    "User-Agent": self.session.headers["User-Agent"],
                    "Referer": "https://www.kugou.com/"
                }
            }
            self._apply_player_meta(result, meta)
            return result

        play_id = id
        if "$" in id:
            _, play_id = id.split("$", 1)
        meta = self._unpack_play_id(play_id)
        hash_val = meta.get("hash", "")
        album_id = meta.get("album_id", "")
        if not hash_val:
            parts = play_id.split("|")
            hash_val = parts[0]
            album_id = parts[1] if len(parts) > 1 else ""
        if not hash_val:
            return {"parse": 0, "url": "", "msg": "缺少hash"}

        song_info = self._get_song_info(hash_val, album_id)
        if not song_info:
            song_info = self._get_song_info(hash_val, "")
        if not song_info or song_info.get("status") != 1:
            return {"parse": 0, "url": "", "msg": "该歌曲需要付费或暂无播放资源"}

        play_url = song_info.get("url") or ""
        if not play_url:
            backup = song_info.get("backup_urls") or song_info.get("backup_url")
            if isinstance(backup, list) and backup:
                play_url = backup[0]
            elif isinstance(backup, str) and backup:
                play_url = backup
        if not play_url:
            return {"parse": 0, "url": "", "msg": "无播放链接"}

        subs = []
        lrc = self._get_lyric(hash_val)
        if lrc:
            ssa = self._create_ssa_subtitle(lrc)
            if ssa:
                ssa_b64 = base64.b64encode(ssa.encode('utf-8')).decode('utf-8')
                subs.append({
                    "name": "歌词",
                    "url": f"data:text/x-ssa;base64,{ssa_b64}",
                    "format": "text/x-ssa",
                    "selected": True
                })

        result = {
            "parse": 0, "url": play_url,
            "music_player": 1,
            "header": {
                "User-Agent": self.session.headers["User-Agent"],
                "Referer": "https://www.kugou.com/"
            },
            "subs": subs
        }
        self._apply_player_meta(result, meta)
        return result
 
    def searchContent(self, key, quick, pg="1"):
        page = int(pg) if pg else 1
        songs = self._search_songs(key, page=page, pagesize=20)
        if not songs:
            return {"list": [], "page": pg, "pagecount": 0, "limit": 0, "total": 0}
        video_list = []
        for song in songs:
            hash_val = self._extract_best_hash(song)
            if not hash_val:
                continue
            name = self._get_song_name(song)
            singer = self._get_singer_name(song)
            pic = self._get_song_cover(song)
            album_id = self._get_album_id(song)
            mvhash = self._get_mv_hash(song)
            vod_id = f"{hash_val}|{album_id}|{mvhash}|{pic}"
            video_list.append({
                "vod_id": vod_id,
                "vod_name": name,
                "vod_pic": pic,
                "vod_remarks": singer,
            })
        return {
            "list": video_list,
            "page": pg, "pagecount": page + 1 if len(video_list) >= 20 else page,
            "limit": len(video_list), "total": len(video_list)
        }
 
                                  
    def _get_rank_list(self):
        url = "http://mobilecdnbj.kugou.com/api/v3/rank/list"
        params = {
            "version": "9108", "plat": "0", "showtype": "2",
            "parentid": "0", "apiver": "6", "area_code": "1",
            "withsong": "0", "with_res_tag": "0",
        }
        try:
            resp = self.session.get(url, params=params, timeout=(5, 15))
            resp.raise_for_status()
            return resp.json().get("data", {}).get("info", []) or []
        except Exception as e:
            self.log(f"获取榜单列表失败: {e}")
            return []
 

    def _get_all_rank_songs(self, rank_id, pagesize=100, max_pages=30):
        songs = []
        seen = set()
        total = 0
        page = 1
        while page <= max_pages:
            data = self._get_rank_songs(rank_id, page=page, pagesize=pagesize)
            batch = data.get("songs", []) or []
            try:
                total = max(total, int(data.get("total") or 0))
            except Exception:
                total = total or 0
            if not batch:
                break
            for song in batch:
                h = self._extract_best_hash(song)
                key = h or json.dumps(song, ensure_ascii=False, sort_keys=True)
                if key in seen:
                    continue
                seen.add(key)
                songs.append(song)
            if total and len(songs) >= total:
                break
            if len(batch) < pagesize:
                break
            page += 1
        self.log(f"榜单{rank_id}加载歌曲 {len(songs)}/{total or len(songs)} 首")
        return songs, total or len(songs)

    def _pack_play_id(self, hash_val, album_id="", pic="", name="", singer=""):
        data = {"hash": hash_val or "", "album_id": album_id or "", "pic": pic or "", "name": name or "", "singer": singer or ""}
        raw = json.dumps(data, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        return "song:" + base64.urlsafe_b64encode(raw).decode("utf-8").rstrip("=")

    def _pack_mv_id(self, mv_hash, pic="", name="", singer=""):
        data = {"hash": mv_hash or "", "album_id": "", "pic": pic or "", "name": name or "", "singer": singer or ""}
        raw = json.dumps(data, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        return "mvb:" + base64.urlsafe_b64encode(raw).decode("utf-8").rstrip("=")

    def _unpack_play_id(self, play_id):
        prefix = ""
        if play_id.startswith("song:"):
            prefix = "song:"
        elif play_id.startswith("mvb:"):
            prefix = "mvb:"
        if not prefix:
            return {}
        try:
            raw = play_id[len(prefix):]
            raw += "=" * ((4 - len(raw) % 4) % 4)
            data = json.loads(base64.urlsafe_b64decode(raw.encode("utf-8")).decode("utf-8"))
            return data if isinstance(data, dict) else {}
        except Exception as e:
            self.log(f"解析播放元数据失败: {e}")
            return {}

    def _apply_player_meta(self, result, meta):
        if not meta:
            return result
        name = meta.get("name") or ""
        singer = meta.get("singer") or ""
        pic = meta.get("pic") or ""
        if name:
            result["title"] = name
            result["name"] = name
            result["vod_name"] = name
        if singer:
            result["artist"] = singer
            result["vod_actor"] = singer
        if pic:
            result["pic"] = pic
            result["cover"] = pic
            result["vod_pic"] = pic
        return result

    def _get_rank_songs(self, rank_id, page=1, pagesize=50):
        url = "http://mobilecdnbj.kugou.com/api/v3/rank/song"
        params = {
            "version": "9108", "ranktype": "0", "plat": "0",
            "pagesize": str(pagesize), "area_code": "1",
            "page": str(page), "rankid": str(rank_id),
            "volid": "35050", "with_res_tag": "0",
        }
        try:
            resp = self.session.get(url, params=params, timeout=(5, 15))
            resp.raise_for_status()
            data = resp.json()
            return {
                "songs": data.get("data", {}).get("info", []) or [],
                "total": data.get("data", {}).get("total", 0)
            }
        except Exception as e:
            self.log(f"获取榜单歌曲失败: {e}")
            return {"songs": [], "total": 0}
 
    def _search_songs(self, keyword, page=1, pagesize=20):
        url = "http://songsearch.kugou.com/song_search_v2"
        params = {
            "keyword": keyword, "page": page,
            "pagesize": pagesize, "platform": "WebFilter",
            "format": "json",
        }
        try:
            resp = self.session.get(url, params=params, timeout=(5, 15))
            resp.raise_for_status()
            return resp.json().get("data", {}).get("lists", []) or []
        except Exception as e:
            self.log(f"搜索失败: {e}")
            return []
 
    def _get_song_info(self, hash_val, album_id=""):
        url = "http://m.kugou.com/app/i/getSongInfo.php"
        params = {"hash": hash_val, "cmd": "playInfo"}
        if album_id:
            params["album_id"] = album_id
        try:
            resp = self.session.get(url, params=params, timeout=(5, 15))
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            self.log(f"获取歌曲信息失败: {e}")
            return None
 
    def _get_mv_urls(self, mv_hash):
        url = "https://m.kugou.com/app/i/mv.php"
        params = {"cmd": "100", "hash": mv_hash, "ismp3": "1", "ext": "mp4"}
        result = {}
        try:
            resp = self.session.get(url, params=params, timeout=(5, 15))
            resp.raise_for_status()
            data = resp.json()
            if data.get("status") != 1:
                return result
            mvdata = data.get("mvdata", {}) or {}
            for q in ["sq", "rq", "le"]:
                info = mvdata.get(q)
                if info:
                    downurl = info.get("downurl") or ""
                    if not downurl and info.get("backupdownurl"):
                        downurl = info["backupdownurl"][0]
                    if downurl:
                        result[q] = downurl
            return result
        except Exception as e:
            self.log(f"获取MV失败: {e}")
            return result
 
    def _get_lyric(self, hash_val):
        try:
            search_url = "http://lyrics.kugou.com/search"
            params = {"ver": 1, "man": "yes", "client": "pc", "hash": hash_val}
            resp = self.session.get(search_url, params=params, timeout=(5, 15))
            resp.raise_for_status()
            data = resp.json()
            candidates = data.get("candidates", [])
            if not candidates:
                return None
            c = candidates[0]
            download_url = "http://lyrics.kugou.com/download"
            params = {
                "ver": 1, "client": "pc",
                "id": c.get("id"),
                "accesskey": c.get("accesskey"),
                "fmt": "lrc", "charset": "utf8"
            }
            resp2 = self.session.get(download_url, params=params, timeout=(5, 15))
            resp2.raise_for_status()
            data2 = resp2.json()
            content = data2.get("content")
            if content:
                return base64.b64decode(content).decode("utf-8")
            return None
        except Exception as e:
            self.log(f"获取歌词失败: {e}")
            return None
 
                                

    def _first_value(self, *values):
        for value in values:
            if value:
                return value
        return ""

    def _get_quality_hashes(self, song, fallback_hash=""):
        extra = song.get("extra") or {}
        if not isinstance(extra, dict):
            extra = {}
        return {
            "无损音质": self._first_value(song.get("sqhash"), song.get("SQFileHash"), song.get("SuperFileHash"), extra.get("sqhash"), extra.get("SQFileHash")),
            "高清音质": self._first_value(song.get("320hash"), song.get("HQFileHash"), song.get("320FileHash"), extra.get("320hash"), extra.get("HQFileHash")),
            "标准音质": self._first_value(extra.get("128hash"), song.get("128hash"), song.get("hash"), song.get("FileHash"), song.get("Hash"), fallback_hash),
        }

    def _episode_title(self, idx, item):
        origin_idx = item.get("_origin_idx") or idx
        name = (item.get("name") or "未知歌曲").replace("$", " " ).replace("#", " " ).strip()
        singer = (item.get("singer") or "").replace("$", " " ).replace("#", " " ).strip()
        title = f"{int(origin_idx):02d}. {name}"
        if singer and singer != "未知歌手":
            title += f" - {singer}"
        return title
 
    def _extract_best_hash(self, song):
        order = [
            "sqhash", "SQFileHash", "SuperFileHash",
            "320hash", "HQFileHash",
            "hash", "FileHash", "Hash",
            "ResFileHash",
        ]
        for key in order:
            h = song.get(key)
            if h:
                return h
        return None
 
    def _get_song_cover(self, song):
        cover = (
            song.get("album_sizable_cover")
            or song.get("album_img")
            or song.get("img")
            or song.get("cover")
            or song.get("AlbumImage")
            or song.get("albumImg")
            or song.get("Image")
            or ""
        )
        if cover and "{size}" in cover:
            cover = cover.replace("{size}", "400")
        return cover
 
    def _get_mv_hash(self, song):
                
        h = (
            song.get("MvHash")
            or song.get("mvhash")
            or song.get("MVHash")
            or ""
        )
        if h:
            return h
                          
        mvdata = song.get("mvdata")
        if mvdata and isinstance(mvdata, list) and len(mvdata) > 0:
            return mvdata[0].get("hash", "")
        return ""
 
    def _get_song_name(self, song):
        return song.get("songname") or song.get("SongName") or "未知歌曲"
 
    def _get_singer_name(self, song):
        authors = song.get("authors")
        if authors and isinstance(authors, list):
            names = "、".join(
                a.get("author_name", "") or a.get("name", "")
                for a in authors
                if a.get("author_name") or a.get("name")
            )
            if names:
                return names
        singers = song.get("Singers")
        if singers and isinstance(singers, list):
            names = "、".join(s.get("name", "") for s in singers if s.get("name"))
            if names:
                return names
        return (
            song.get("singerName")
            or song.get("SingerName")
            or song.get("singer_name")
            or song.get("author_name")
            or "未知歌手"
        )
 
    def _extract_singer_from_info(self, song_info):
        authors = song_info.get("authors")
        if authors and isinstance(authors, list):
            names = "、".join(
                a.get("author_name", "") or a.get("name", "")
                for a in authors
                if a.get("author_name") or a.get("name")
            )
            if names:
                return names
        return (
            song_info.get("singerName")
            or song_info.get("author_name")
            or song_info.get("SingerName")
            or song_info.get("artistName")
            or "未知歌手"
        )
 
    def _get_album_id(self, song):
        return str(
            song.get("album_id")
            or song.get("AlbumID")
            or song.get("albumid")
            or ""
        )
 
                                  
    def _create_ssa_subtitle(self, lrc_text):
        lines = []
        pattern = r'\[(\d{2}):(\d{2})\.(\d{2})\](.*)'
        for line in lrc_text.split('\n'):
            match = re.match(pattern, line)
            if match:
                minutes = int(match.group(1))
                seconds = int(match.group(2))
                hundredths = int(match.group(3))
                text = match.group(4).strip()
                total_seconds = minutes * 60 + seconds + hundredths / 100.0
                if text:
                    lines.append({'start': total_seconds, 'text': text})
        if not lines:
            return ""
        ssa_header = """[Script Info]
ScriptType: v4.00+
Collisions: Normal
PlayResX: 1280
PlayResY: 720
Timer: 100.0000
WrapStyle: 0
 
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: CENTER,Roboto,60,&H0000FF00,&H00808080,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,2,2,2,0,0,340,1
Style: TOP,Roboto,55,&H0000FFFF,&H00808080,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,1,1,2,0,0,200,1
Style: BOTTOM,Roboto,55,&H0000FFFF,&H00808080,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,1,1,2,0,0,500,1
 
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
        def fmt(seconds):
            h = int(seconds // 3600)
            m = int((seconds % 3600) // 60)
            s = int(seconds % 60)
            cs = int((seconds * 100) % 100)
            return f"{h}:{m:02d}:{s:02d}.{cs:02d}"
        events = []
        for i, current in enumerate(lines):
            end = lines[i+1]['start'] if i+1 < len(lines) else current['start'] + 5.0
            events.append(f"Dialogue: 1,{fmt(current['start'])},{fmt(end)},CENTER,,0,0,0,,{current['text']}")
            if i > 0:
                prev = lines[i-1]
                events.append(f"Dialogue: 2,{fmt(current['start'])},{fmt(end)},TOP,,0,0,0,,{prev['text']}")
            if i+1 < len(lines):
                next_line = lines[i+1]
                events.append(f"Dialogue: 3,{fmt(current['start'])},{fmt(end)},BOTTOM,,0,0,0,,{next_line['text']}")
        return ssa_header + "\n".join(events)
 

    def _html_get(self, url):
        try:
            headers = dict(self.session.headers)
            headers.update({"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36", "Referer": "https://www.kugou.com/"})
            r = self.session.get(url, headers=headers, timeout=(5, 15))
            r.encoding = r.apparent_encoding or "utf-8"
            return r.text
        except Exception as e:
            self.log(f"请求页面失败: {e}")
            return ""

    def _b64(self, text):
        return base64.urlsafe_b64encode((text or "").encode("utf-8")).decode("utf-8").rstrip("=")

    def _unb64(self, text):
        try:
            raw = text or ""
            raw += "=" * ((4 - len(raw) % 4) % 4)
            return base64.urlsafe_b64decode(raw.encode("utf-8")).decode("utf-8")
        except Exception:
            return ""

    def _fix_pic(self, u):
        if not u:
            return ""
        if u.startswith("//"):
            u = "https:" + u
        u = re.sub(r"/(100|150|240)/", "/400/", u)
        u = u.replace("{size}", "400")
        return u

    def _playlist_list(self, sort_id, pg):
        items, seen = [], set()
        start_page = int(pg or 1)
        pat = """<li class=['\"]s_(\\d+)['\"][\\s\\S]*?<a[^>]+title=['\"]([^'\"]+)['\"][^>]+href=['\"][^'\"]*songlist/([^/]+)/['\"][\\s\\S]*?_src=['\"]([^'\"]*)['\"]"""
        for page in range(start_page, start_page + 15):
            html = self._html_get(f"https://www.kugou.com/yy/special/index/{page}-{sort_id}-0.html")
            batch = []
            for m in re.finditer(pat, html):
                sid, title, egcid, pic = m.group(1), self._clean(m.group(2)), m.group(3), self._fix_pic(m.group(4))
                if sid in seen:
                    continue
                seen.add(sid)
                batch.append({"vod_id": "plist_" + self._b64(f"{sid}|{title}|{pic}"), "vod_name": title, "vod_pic": pic, "vod_remarks": "歌单", "vod_tag": "folder"})
            if not batch:
                break
            items.extend(batch)
        return {"list": items, "page": pg, "pagecount": int(pg or 1), "limit": len(items), "total": len(items)}

    def _playlist_song_list(self, tid, pg):
        raw = self._unb64(tid[6:]) if tid.startswith("plist_") else ""
        sid = raw.split("|")[0] if raw else ""
        songs, total = self._get_all_playlist_songs(sid)
        video_list = []
        for song in songs:
            hash_val = self._extract_best_hash(song)
            if not hash_val:
                continue
            name = self._kg_song_name(song)
            singer = self._kg_singer_name(song)
            pic = self._kg_song_pic(song)
            album_id = self._get_album_id(song)
            mvhash = self._get_mv_hash(song)
            video_list.append({"vod_id": f"{hash_val}|{album_id}|{mvhash}|{pic}|plist:{sid}|1", "vod_name": name, "vod_pic": pic, "vod_remarks": singer})
        return {"list": video_list, "page": pg, "pagecount": int(pg or 1), "limit": len(video_list), "total": total or len(video_list)}

    def _singer_area(self, tid, pg):
        cid = tid.split("_", 1)[1] if "_" in tid else "1"
        return self._singer_list(cid, pg)

    def _singer_list(self, cat_id, pg):
        html = self._html_get(f"https://m.kugou.com/singer/list/{cat_id}")
        start = html.find('id="panelList"')
        if start < 0:
            start = html.find("id='panelList'")
        end = html.find("</ul>", start) if start >= 0 else -1
        frag = html[start:end] if start >= 0 and end > start else html
        items, seen = [], set()
        for li in re.findall(r"<li[\s\S]*?</li>", frag):
            mid = re.search(r"/singer/info/([^/]+)/", li)
            mpic = re.search("""_src=['\"]([^'\"]+)['\"]""", li) or re.search("""data-src=['\"]([^'\"]+)['\"]""", li)
            mname = re.search("""<p[^>]*>([\\s\\S]*?)</p>""", li)
            if not mid or not mname:
                continue
            sid = mid.group(1)
            name = self._clean(re.sub(r"<[^>]+>", " ", mname.group(1)))
            pic = self._fix_pic(mpic.group(1)) if mpic else ""
            if not name or sid in seen:
                continue
            seen.add(sid)
            items.append({"vod_id": "singer_" + self._b64(name), "vod_name": name, "vod_pic": pic, "vod_remarks": "歌手", "vod_tag": "folder"})
        return {"list": items, "page": pg, "pagecount": int(pg or 1), "limit": len(items), "total": len(items)}

    def _singer_songs(self, sid_name, pg):
        name = sid_name.split(":", 1)[1] if ":" in sid_name else sid_name
        songs, seen, empty = [], set(), 0
        for page in range(1, 51):
            batch = self._search_songs(name, page=page, pagesize=30)
            if not batch:
                break
            before = len(songs)
            for song in batch:
                h = self._extract_best_hash(song)
                if h and h not in seen:
                    seen.add(h)
                    songs.append(song)
            if len(songs) == before:
                empty += 1
                if empty >= 2:
                    break
            else:
                empty = 0
            if len(batch) < 30:
                break
        video_list = []
        for song in songs:
            hash_val = self._extract_best_hash(song)
            if not hash_val:
                continue
            name2 = self._get_song_name(song)
            singer = self._get_singer_name(song)
            pic = self._get_song_cover(song)
            album_id = self._get_album_id(song)
            mvhash = self._get_mv_hash(song)
            video_list.append({"vod_id": f"{hash_val}|{album_id}|{mvhash}|{pic}", "vod_name": name2, "vod_pic": pic, "vod_remarks": singer})
        return {"list": video_list, "page": pg, "pagecount": int(pg or 1), "limit": len(video_list), "total": len(video_list)}


    def _clean(self, t):
        return re.sub(r'\s+', ' ', html_lib.unescape(t or '')).strip()

    def _get_all_playlist_songs(self, sid, pagesize=100, max_pages=30):
        songs, seen, total, page = [], set(), 0, 1
        while page <= max_pages:
            data = self._get_playlist_songs(sid, page, pagesize)
            batch = data.get("songs", []) or []
            try:
                total = max(total, int(data.get("total") or 0))
            except Exception:
                pass
            if not batch:
                break
            for song in batch:
                h = self._extract_best_hash(song)
                if h and h not in seen:
                    seen.add(h)
                    songs.append(song)
            if total and len(songs) >= total:
                break
            if len(batch) < pagesize:
                break
            page += 1
        return songs, total or len(songs)

    def _get_playlist_songs(self, sid, page=1, pagesize=100):
        try:
            r = self.session.get("http://mobilecdnbj.kugou.com/api/v3/special/song", params={"version": "9108", "plat": "0", "pagesize": str(pagesize), "page": str(page), "specialid": str(sid), "with_res_tag": "0"}, timeout=(5, 15))
            data = r.json().get("data", {})
            return {"songs": data.get("info", []) or [], "total": data.get("total", 0)}
        except Exception as e:
            self.log(f"获取歌单歌曲失败: {e}")
            return {"songs": [], "total": 0}


    def _kg_song_name(self, song):
        fn = song.get("FileName") or song.get("Filename") or song.get("filename") or song.get("fileName") or song.get("audio_name") or song.get("remark") or ""
        return song.get("songname") or song.get("SongName") or song.get("songName") or song.get("name") or song.get("audio_name") or self._clean(fn.split(" - ", 1)[-1]) or "未知歌曲"

    def _kg_singer_name(self, song):
        authors = song.get("authors")
        if isinstance(authors, list):
            names = "、".join(a.get("author_name", "") or a.get("name", "") for a in authors if a.get("author_name") or a.get("name"))
            if names:
                return names
        fn = song.get("FileName") or song.get("Filename") or song.get("filename") or song.get("fileName") or song.get("audio_name") or song.get("remark") or ""
        return song.get("singerName") or song.get("SingerName") or song.get("singer_name") or song.get("author_name") or song.get("singername") or song.get("author") or self._clean(fn.split(" - ", 1)[0]) or "未知歌手"

    def _kg_song_pic(self, song):
        trans = song.get("trans_param") or {}
        if not isinstance(trans, dict):
            trans = {}
        pic = song.get("album_sizable_cover") or song.get("sizable_cover") or song.get("album_img") or song.get("img") or song.get("cover") or song.get("pic") or trans.get("union_cover") or trans.get("union_cover_400") or ""
        return self._fix_pic(pic)

    def localProxy(self, params):
        return [404, "text/plain", b"not found"]
