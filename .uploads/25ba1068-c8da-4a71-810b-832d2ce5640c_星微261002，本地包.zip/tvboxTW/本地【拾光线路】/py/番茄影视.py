# -*- coding: utf-8 -*-
# 番茄影视 (sxlianyang.com) TVBox 爬虫源
# 模板: MacCMS (mxone) 注意: 仅无 www 主域可用, www 被 WAF 拦截
# 路由:
#   分类列表 /sh/{tid}--------{pg}---.html
#   详情     /d/{id}.html
#   播放     /p/{id}-{from}-{ep}.html   (player_aaaa.encrypt=2: url 为 base64(URL编码) 双重编码的直链)
#   搜索     /s.html?wd={关键词}
# 线路(详情页 tab 与 blocklist 一一对应): 1=无广超清 2=如意资源1 3=优质资源1 4=优酷视频(网页源, 不可直连)
import re
import json
import base64
import urllib.parse

from base.spider import Spider


class Spider(Spider):
    def init(self, extend=""):
        self.host = "https://sxlianyang.com"
        if extend and "://" in extend:
            self.host = extend.strip().rstrip("/")
        self.session = _new_session()
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36",
            "Referer": self.host + "/",
        }
        self.session.headers.update(self.headers)
        self.cats = [
            ("20", "电影"), ("35", "连续剧"), ("55", "短剧"),
            ("43", "综艺节目"), ("48", "动漫"), ("54", "影视解说"),
            ("63", "预告片"),
        ]

    def getName(self):
        return "sxlianyang"

    def homepageContent(self, filter):
        return self.homeContent(filter)

    def homeContent(self, filter):
        result = {"class": [{"type_id": c, "type_name": n} for c, n in self.cats],
                  "filters": {}}
        try:
            html = self._get(self.host + "/")
            result["list"] = self._parse_list(html)
        except Exception:
            result["list"] = []
        return result

    def homeVideoContent(self):
        return self.homeContent(False)

    def categoryContent(self, tid, pg, filter, extend):
        try:
            page = max(1, int(pg))
        except (TypeError, ValueError):
            page = 1
        url = "%s/sh/%s--------%d---.html" % (self.host, tid, page)
        try:
            html = self._get(url)
        except Exception:
            return {"page": page, "pagecount": 0, "limit": 0, "total": 0, "list": []}
        items = self._parse_list(html)
        pagecount = self._parse_pagecount(html, tid)
        return {"page": page, "pagecount": pagecount, "limit": len(items),
                "total": pagecount * max(len(items), 1), "list": items}

    def detailContent(self, ids):
        if not ids:
            return {"list": []}
        vid = str(ids[0])
        if not vid.isdigit():
            m = re.search(r"(\d+)", vid)
            vid = m.group(1) if m else ""
        if not vid:
            return {"list": []}
        try:
            html = self._get("%s/d/%s.html" % (self.host, vid))
        except Exception:
            return {"list": []}
        vod = {"vod_id": vid, "vod_name": "", "vod_pic": "", "vod_remarks": "",
               "vod_content": "", "vod_play_from": "", "vod_play_url": ""}
        m = re.search(r'<h1[^>]*class="[^"]*page-title[^"]*"[^>]*>(.*?)</h1>', html, re.S)
        vod["vod_name"] = self._clean(m.group(1)) if m else ""
        vod["vod_pic"] = self._detail_pic(html)
        m = re.search(r'class="[^"]*(?:video-info-content|vod_content)[^"]*"[^>]*>\s*<span>\s*<p>(.*?)</p>', html, re.S)
        vod["vod_content"] = self._clean(m.group(1)) if m else ""
        m = re.search(r'<span class="video-info-itemtitle">\s*备注：\s*</span>\s*<div[^>]*>([^<]+)</div>', html, re.S)
        vod["vod_remarks"] = m.group(1).strip() if m else ""
        self._fill_play(html, vod, vid)
        return {"list": [vod]}

    def searchContent(self, key, quick):
        try:
            url = "%s/s.html?wd=%s" % (self.host, urllib.parse.quote(str(key)))
            html = self._get(url)
            items = self._parse_list(html)
        except Exception:
            items = []
        return {"list": items, "page": 1, "pagecount": 1 if items else 0,
                "limit": len(items), "total": len(items)}

    def playerContent(self, flag, id, vipFlags):
        body = dict(id) if isinstance(id, dict) else None
        pid = str((body or {}).get("id") if body else id or "")
        m = re.match(r"(\d+)-(\d+)-(\d+)$", pid)
        if not m:
            return {}
        vid, fid, ep = m.group(1), m.group(2), m.group(3)
        try:
            html = self._get("%s/p/%s-%s-%s.html" % (self.host, vid, fid, ep))
        except Exception:
            return {}
        url = self._extract_player_url(html)
        if not url:
            return {}
        # 优酷等线路解码后为网页而非媒体直链, 无法直接播放
        if not re.search(r"\.(m3u8|mp4|flv)(\?|$)", url, re.I):
            return {}
        if not self._probe_media(url):
            return {}
        return {"parse": 0, "jx": 0, "playUrl": "", "url": url,
                "header": {"User-Agent": self.headers["User-Agent"],
                           "Referer": self.host + "/"}}

    # ---------- 内部工具 ----------

    def _fill_play(self, html, vod, vid):
        # 线路名按出现顺序
        tabs = [m.group(1) for m in re.finditer(r'data-dropdown-value="([^"]+)"', html)]
        froms, ep_groups = [], []
        for m in re.finditer(r'<div class="module-blocklist">\s*<div class="sort-item"[^>]*>.*?</div>\s*</div>', html, re.S):
            block = m.group(0)
            eps = re.findall(r'href="/p/%s-(\d+)-(\d+)\.html"[^>]*>\s*<span>([^<]*)</span>' % re.escape(vid), block)
            if not eps:
                continue
            froms.append(eps[0][0])
            ep_groups.append(eps)
        if not ep_groups:
            return
        if len(tabs) < len(ep_groups):
            tabs = tabs + ["线路%s" % f for f in froms[len(tabs):]]
        names = tabs[:len(ep_groups)]
        play_uris, play_names = [], []
        for name, fid, eps in zip(names, froms, ep_groups):
            if not name or not eps:
                continue
            tail = ["%s$%s-%s-%s" % (t.strip() or ep, vid, fid, ep) for ep, _, t in eps]
            play_names.append(name)
            play_uris.append("#".join(tail))
        if not play_uris:
            return
        vod["vod_play_from"] = "$$$".join(play_names[:len(play_uris)])
        vod["vod_play_url"] = "$$$".join(play_uris)

    def _extract_player_url(self, html):
        i = html.find("player_aaaa=")
        if i < 0:
            return ""
        raw = self._balanced_json(html, i + len("player_aaaa="))
        if not raw:
            return ""
        obj = None
        try:
            obj = json.loads(raw)
        except Exception:
            try:
                obj = json.loads(raw.encode("utf-8").decode("unicode_escape"))
            except Exception:
                return ""
        if not obj:
            return ""
        enc = str(obj.get("url") or "")
        if not enc:
            return ""
        try:
            level1 = base64.b64decode(enc).decode("utf-8", "ignore")
        except Exception:
            return ""
        return urllib.parse.unquote(level1)

    def _balanced_json(self, html, start):
        """从 start 起做花括号配平, 返回配平的 JSON 串(忽略字符串内的括号与转义)"""
        depth = 0
        in_str = False
        esc = False
        for p in range(start, len(html)):
            ch = html[p]
            if in_str:
                if esc:
                    esc = False
                elif ch == "\\":
                    esc = True
                elif ch == '"':
                    in_str = False
                continue
            if ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return html[start:p + 1]
            elif ch == ";":
                if depth == 0:
                    return ""
        return ""

    def _probe_media(self, url):
        try:
            r = self.session.get(url, timeout=10, stream=True)
            try:
                head = r.content[:300].decode("utf-8", "ignore")
            finally:
                r.close()
            return "#EXTM3U" in head
        except Exception:
            return False

    def _parse_list(self, html):
        items = []
        # 列表页: 封面 a(/d/) 在后, 图 img data-src 在前
        pat1 = re.compile(
            r'<div class="module-item-cover">.*?<a href="/d/(\d+)\.html"[^>]*title="([^"]*)"[^>]*>.*?</a>\s*'
            r'<img[^>]*data-src="([^"]+)"[^>]*>',
            re.S,
        )
        # 搜索页: 封面 a 为 /p/ 播放链接, 图在前; 正文区另有 /d/ 链接
        pat2 = re.compile(
            r'<div class="module-item">.*?<a href="/d/(\d+)\.html"[^>]*title="([^"]*)"[^>]*>.*?</a>',
            re.S,
        )
        seen = set()
        for m in pat1.finditer(html):
            vid, name, pic = m.groups()
            if vid in seen:
                continue
            seen.add(vid)
            rem = self._entry_remarks(html, m.start(), m.end())
            items.append({"vod_id": vid, "vod_name": name, "vod_pic": pic,
                          "vod_remarks": rem, "vod_content": ""})
        if not items and pat2.search(html):
            # 搜索页: 以 a(/d/) 定位, 反查其所在 module-item 内的 data-src
            for m in pat2.finditer(html):
                vid, name = m.group(1), m.group(2)
                if vid in seen:
                    continue
                seen.add(vid)
                block = html[m.start() - 1200:m.start() + 200]
                mm = re.search(r'data-src="(https?://[^"]+)"', block)
                pic = mm.group(1) if mm else ""
                rem = self._entry_remarks(html, m.start(), m.end())
                items.append({"vod_id": vid, "vod_name": name, "vod_pic": pic,
                              "vod_remarks": rem, "vod_content": ""})
        return items

    def _entry_remarks(self, html, s0, e0):
        seg = html[e0:e0 + 1500]
        m = re.search(r'class="module-item-text">([^<]+)</div>', seg)
        if m:
            return m.group(1).strip()
        m = re.search(r'class="video-serial"[^>]*>([^<]+)</a>', html[max(0, s0 - 800):e0])
        if m:
            return m.group(1).strip()
        return ""

    def _parse_pagecount(self, html, tid):
        nums = []
        pat = urllib.parse.quote(str(tid))
        for m in re.finditer(r'/sh/%s--------(\d+)---\.html' % re.escape(pat), html):
            try:
                nums.append(int(m.group(1)))
            except ValueError:
                pass
        return max(nums) if nums else 1

    def _detail_pic(self, html):
        m = re.search(r'class="[^"]*video-cover[^"]*"[^>]*>.*?<img[^>]*data-src="([^"]+)"', html, re.S)
        if m:
            return m.group(1)
        m = re.search(r'property="og:image" content="([^"]+)"', html)
        if m:
            pic = m.group(1)
            # 该站 og:image 会拼接域名前缀, 清洗出协议头
            mm = re.search(r'https?://[^"\']+', pic)
            return mm.group(0) if mm else ""
        return ""

    def _clean(self, s):
        return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", s or "")).strip()

    def _get(self, url):
        r = self.session.get(url, timeout=15)
        r.raise_for_status()
        return r.text


def _new_session():
    import requests
    return requests.Session()