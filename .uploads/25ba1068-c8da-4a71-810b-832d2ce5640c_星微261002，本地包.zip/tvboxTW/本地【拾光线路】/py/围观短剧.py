from base.spider import Spider as BaseSpider
import requests
import json
import sys
import random
import string

sys.path.append('..')
host = "https://api.drama.9ddm.com/"
headers = {
    'User-Agent': 'okhttp/5.1.0',
    'Content-Type': 'application/json;charset=utf-8'
}


class Spider(BaseSpider):
    def getName(self):
        return "小心儿悠悠"

    def init(self, extend):
        # 模拟 Android Build.MODEL, Build.BRAND
        self.device_name = "SM-G988N"
        self.device_brand = "samsung"
        # 生成16位随机 clientInfo
        self.client_info = ''.join(random.choices(string.ascii_letters + string.digits, k=16))

        self.common_params = {
            'version_code': '1500',
            'version_name': '1.5.0',
            'os_type': '1',
            'device_name': self.device_name,
            'device_type': 'phone',
            'is_first_day': 'true',
            'is_first_24h': 'true',
            'app_launch_way': 'icon',
            'default_homepage': 'homepage_interaction',
            'device_owning_firm': self.device_brand,
            'font_scale': 'default',
            'clientInfo': self.client_info,
        }

    def isVideoFormat(self, url):
        pass

    def manualVideoCheck(self):
        pass

    def homeContent(self, filter):
        try:
            url = host + "/drama/home/shortVideoTags"
            response = requests.get(url, headers=headers, timeout=5, params=self.common_params)
            data = response.json()
            tags = data.get("tags", [])
            if not isinstance(tags, list):
                tags = []

            classes = []
            filters = {}
            audiences = ["男频", "女频", "都市", "古装"]
            orders = ["最热", "最新"]

            for tag in tags:
                # tag如果是dict就取id和name，兼容接口两种返回格式
                if isinstance(tag, dict):
                    tid = tag.get("id", str(tag.get("tag", "")))
                    tname = tag.get("tag", tag.get("name", ""))
                else:
                    tid = str(tag)
                    tname = str(tag)
                classes.append({
                    "type_id": tid,
                    "type_name": tname
                })
            # 全局过滤器，不要每个分类重复生成
            filter_list = [
                {
                    "key": "audience",
                    "name": "受众",
                    "value": [{"n": "全部", "v": ""}]
                },
                {
                    "key": "order",
                    "name": "排序",
                    "value": [{"n": "全部", "v": ""}]
                }
            ]
            for audience in audiences:
                filter_list[0]["value"].append({"n": audience, "v": audience})
            for order in orders:
                filter_list[1]["value"].append({"n": order, "v": order})
            filters["global"] = filter_list

            return {
                "class": classes,
                "filters": filters
            }
        except Exception as e:
            print(f"homeContent error: {str(e)}")
            return {"class": [], "filters": {}}

    def homeVideoContent(self):
        # 首页推荐调用分类接口，tid空，pg=1，ext空
        return self.categoryContent(tid="", pg="1", filter=None, ext={})

    def categoryContent(self, tid, pg, filter, ext):
        videos = []
        try:
            page = int(pg) if pg else 1
            audience = ext.get("audience", "") if ext else ""
            order = ext.get("order", "") if ext else ""
            post_data = {
                "audience": audience,
                "order": order,
                "page": page,
                "pageSize": 30,
                "searchWord": "",
                "subject": tid
            }
            url = host + "/drama/home/search"
            response = requests.post(url, headers=headers, data=json.dumps(post_data),
                                     timeout=5, params=self.common_params)
            data = response.json()
            items = data.get("data", [])
            if not isinstance(items, list):
                items = []
            for item in items:
                view_count = item.get("viewCount", 0)
                episode_count = item.get("episodeCount", 0)
                remarks_parts = []
                if view_count:
                    if view_count >= 10000:
                        remarks_parts.append(f"{view_count/10000:.1f}万播放")
                    else:
                        remarks_parts.append(f"{view_count}播放")
                if episode_count:
                    remarks_parts.append(f"{episode_count}集")
                vod_remarks = " · ".join(remarks_parts) if remarks_parts else ""
                videos.append({
                    "vod_id": item.get("oneId", ""),
                    "vod_name": item.get("title", ""),
                    "vod_pic": item.get("vertPoster", item.get("horzPoster", "")),
                    "vod_remarks": vod_remarks
                })
            has_next = len(items) >= 30
            pagecount = page + 1 if has_next else page
            return {
                'list': videos,
                'page': pg,
                'pagecount': pagecount,
                'limit': 30,
                'total': len(videos) if not has_next else 99999
            }
        except Exception as e:
            print(f"categoryContent error: {str(e)}")
            return {'list': videos, 'page': pg, 'pagecount': 1, 'limit': 30, 'total': 0}

    def detailContent(self, ids):
        try:
            vid = ids[0]
            params = {
                "oneId": vid,
                "page": 1,
                "pageSize": 1000,
                "userId": 0,
                "queryAll": "true"
            }
            params.update(self.common_params)
            url = host + "/drama/home/shortVideoDetail"
            response = requests.get(url, headers=headers, timeout=5, params=params)
            data = response.json()
            # 修复：接口返回data是字典，剧集列表在data["shortVideoList"]
            data_body = data.get("data", {})
            video_data = data_body.get("shortVideoList", [])
            if not isinstance(video_data, list) or len(video_data) == 0:
                return {}
            first_episode = video_data[0]
            actors = []
            short_play_tags = []
            description = data.get("description", "")
            episode_count = len(video_data)
            view_count = first_episode.get("collectionCount", 0)

            # 搜索接口补全信息
            try:
                search_url = host + "/drama/home/search"
                post_data = {
                    "audience": "",
                    "page": 1,
                    "pageSize": 1,
                    "searchWord": first_episode.get("title", ""),
                    "subject": ""
                }
                search_response = requests.post(search_url, headers=headers,
                                                data=json.dumps(post_data), timeout=5,
                                                params=self.common_params)
                search_data = search_response.json()
                if search_data.get("data"):
                    for item in search_data["data"]:
                        if item.get("oneId") == vid:
                            description = item.get("description", description)
                            actors = item.get("actors", [])
                            short_play_tags = item.get("shortPlayTag", [])
                            episode_count = item.get("episodeCount", episode_count)
                            view_count = item.get("viewCount", view_count)
                            break
            except Exception as ex:
                print(f"detail search supplement error:{ex}")

            # 演员信息追加简介
            try:
                actor_items = data_body.get("actorItems", [])
                if actor_items and isinstance(actor_items, list):
                    actor_blocks = []
                    for actor in actor_items:
                        name = actor.get("name", "")
                        role = actor.get("rolePlayingName", "")
                        brief = actor.get("briefIntroduction", "")
                        if name:
                            lines = [f"{name} 饰演 {role}"]
                            if brief:
                                lines.append(brief)
                            actor_blocks.append("\n".join(lines))
                    if actor_blocks:
                        description += "\n\n演员信息：\n" + "\n\n".join(actor_blocks)
            except Exception as ex:
                print(f"actor parse error:{ex}")

            remarks_parts = []
            if view_count:
                if view_count >= 10000:
                    remarks_parts.append(f"{view_count/10000:.1f}万")
                else:
                    remarks_parts.append(f"{view_count}")
            if episode_count:
                remarks_parts.append(f"共{episode_count}集")
            vod_remarks = " · ".join(remarks_parts) if remarks_parts else ""

            # 解析年份，只取4位
            pub_date = str(first_episode.get("publishDate", ""))
            vod_year = pub_date[:4] if len(pub_date) >=4 else ""

            play_urls = []
            for episode in video_data:
                episode_index = episode.get('playOrder', 1)
                clarity_list = episode.get('videoClarityList', [])
                if not isinstance(clarity_list, list):
                    clarity_list = []
                episode_id = f"{episode_index}${json.dumps(clarity_list, ensure_ascii=False)}"
                play_urls.append(episode_id)

            vod = {
                "vod_id": vid,
                "vod_name": first_episode.get("title", ""),
                "vod_pic": first_episode.get("vertPoster", ""),
                "vod_remarks": vod_remarks,
                "vod_content": description,
                "vod_play_from": "围观短剧",
                "vod_play_url": "#".join(play_urls),
                "vod_actor": " · ".join(actors) if actors else "",
                "type_name": " · ".join(short_play_tags) if short_play_tags else "",
                "vod_year": vod_year
            }
            return {'list': [vod]}
        except Exception as e:
            print(f"detailContent error: {str(e)}")
            return {}

    def playerContent(self, flag, id, vipFlags):
        clarity_list = []
        try:
            if '$' in id:
                _, json_str = id.split('$', 1)
            else:
                json_str = id
            clarity_list = json.loads(json_str)
            if not isinstance(clarity_list, list):
                clarity_list = []
        except Exception as e:
            print(f"player parse clarity error {e}")

        play_list = []
        for item in clarity_list:
            name = item.get("name", "")
            url = item.get("url", "")
            if name and url:
                play_list.append(name)
                play_list.append(url)
        if play_list:
            return {
                "parse": 0,
                "playUrl": '',
                "url": play_list,
                "header": headers
            }
        return {
            "parse": 0,
            "playUrl": '',
            "url": id,
            "header": headers
        }

    def searchContent(self, key, quick, pg="1"):
        videos = []
        try:
            page = int(pg) if pg else 1
            post_data = {
                "audience": "",
                "order": "",
                "page": page,
                "pageSize": 30,
                "searchWord": key,
                "subject": ""
            }
            url = host + "/drama/home/search"
            response = requests.post(url, headers=headers, data=json.dumps(post_data),
                                     timeout=5, params=self.common_params)
            data = response.json()
            items = data.get("data", [])
            if not isinstance(items, list):
                items = []
            for item in items:
                view_count = item.get("viewCount", 0)
                episode_count = item.get("episodeCount", 0)
                remarks_parts = []
                if view_count:
                    if view_count >= 10000:
                        remarks_parts.append(f"{view_count/10000:.1f}万播放")
                    else:
                        remarks_parts.append(f"{view_count}播放")
                if episode_count:
                    remarks_parts.append(f"{episode_count}集")
                vod_remarks = " · ".join(remarks_parts) if remarks_parts else ""
                videos.append({
                    "vod_id": item.get("oneId",""),
                    "vod_name": item.get("title",""),
                    "vod_pic": item.get("vertPoster", item.get("horzPoster", "")),
                    "vod_remarks": vod_remarks
                })
            has_next = len(items)>=30
            pagecount = page +1 if has_next else page
            return {
                'list': videos,
                'page': pg,
                'pagecount': pagecount,
                'limit': 30,
                'total': 99999 if has_next else len(videos)
            }
        except Exception as e:
            print(f"searchContent error:{str(e)}")
            return {
                'list': videos,
                'page': pg,
                'pagecount': 1,
                'limit': 30,
                'total': 0
            }

    def searchContentPage(self, key, quick, pg):
        return self.searchContent(key, quick, pg)

    def localProxy(self, params):
        return None
