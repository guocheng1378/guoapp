# coding = utf-8
# !/usr/bin/python

from Crypto.Util.Padding import unpad
from Crypto.Util.Padding import pad
from urllib.parse import unquote
from Crypto.Cipher import ARC4
from urllib.parse import quote
from base.spider import Spider
from Crypto.Cipher import AES
from datetime import datetime
from bs4 import BeautifulSoup
from base64 import b64decode
import urllib.request
import urllib.parse
import datetime
import binascii
import requests
import base64
import json
import time
import sys
import re
import os
import hashlib
import html as html_module   # 新增：XML安全转义

sys.path.append('..')

xurl = "https://api.bilibili.com"

headerx = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0',
    'Referer':  'https://www.bilibili.com',
    'Origin':   'https://www.bilibili.com',
    'cookie':   'buvid3=9AB9323A-F21B-1A49-93F8-ABBE7738F82787336infoc; b_nut=1730031187; b_lsid=C5DE8ADD_192CDE4F974; _uuid=39F105341-5ABB-297C-E8AC-193910249F69488356infoc; buvid4=3AAE7EBA-A505-6B5F-153E-EEFE17AA68A888888-024102712-wN48cfQQcbzwQQDk0fiimQ%3D%3D; buvid_fp=799be2784f8761d26ecab89ab3c5982f; bili_ticket=eyJhbGciOiJIUzI1NiIsImtpZCI6InMwMyIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3MzAyOTAzODksImlhdCI6MTczMDAzMTEyOSwicGx0IjotMX0.XzvRhDap3hcbkoNoOeK8lkWjH_SAUCXk8N0JtAfxGhE; bili_ticket_expires=1730290329'
}

pm = ''


class Spider(Spider):
    global xurl
    global headerx

    mixin_key_enc_tab = [
        46, 47, 18, 2, 53, 8, 23, 32, 15, 50, 10, 31, 58, 3, 45, 35, 27, 43, 5,
        49, 33, 9, 42, 19, 29, 28, 14, 39, 12, 38, 41, 13, 37, 48, 7, 16, 24, 55,
        40, 61, 26, 17, 0, 1, 60, 51, 30, 4, 22, 25, 54, 21, 56, 59, 6, 63, 57, 62,
        11, 36, 20, 34, 44, 52
    ]

    def getName(self):
        return "首页"

    def init(self, extend):
        pass

    def isVideoFormat(self, url):
        pass

    def manualVideoCheck(self):
        pass

    @staticmethod
    def safe_get(obj, keys, default=''):
        if not isinstance(obj, dict):
            return default
        for k in keys:
            val = obj.get(k)
            if val is not None and val != '':
                return val
        return default

    def get_mixin_key(self, orig):
        temp = ''
        for i in self.mixin_key_enc_tab:
            if i < len(orig):
                temp += orig[i]
        return temp[:32]

    def enc_wbi(self, params, img_key, sub_key):
        mixin_key = self.get_mixin_key(img_key + sub_key)
        sorted_keys = sorted(params.keys())

        def enc_val(v):
            s = urllib.parse.quote(str(v), safe='')
            return s.replace('!', '').replace("'", '').replace('(', '').replace(')', '').replace('*', '')

        query = '&'.join([f"{urllib.parse.quote(str(k), safe='')}={enc_val(params[k])}" for k in sorted_keys])
        w_rid = hashlib.md5((query + mixin_key).encode()).hexdigest()
        return query + '&w_rid=' + w_rid

    def get_wbi_keys(self):
        url = 'https://api.bilibili.com/x/web-interface/nav'
        resp = requests.get(url, headers=headerx, timeout=10)
        data = resp.json()
        img_url = data['data']['wbi_img']['img_url']
        sub_url = data['data']['wbi_img']['sub_url']
        img_key = img_url.split('/')[-1].split('.')[0]
        sub_key = sub_url.split('/')[-1].split('.')[0]
        return img_key, sub_key

    def base64_encode_str(self, s):
        return base64.b64encode(s.encode('utf-8')).decode('utf-8')

    # ========== 关键修复：XML安全转义 + 空URL过滤 + 字段兼容 ==========
    def build_mpd(self, video, audio_list, duration, min_buf):
        v_id     = str(self.safe_get(video, ['id', 'Id'], '0'))
        v_bw     = self.safe_get(video, ['bandwidth'], 0)
        v_codecs = self.safe_get(video, ['codecs'], '')
        v_width  = self.safe_get(video, ['width'], 0)
        v_height = self.safe_get(video, ['height'], 0)
        v_fps    = self.safe_get(video, ['frame_rate', 'frameRate'], 25)
        v_sar    = self.safe_get(video, ['sar'], '1:1')
        v_mime   = self.safe_get(video, ['mime_type', 'mimeType'], 'video/mp4')
        v_base   = self.safe_get(video, ['baseUrl', 'base_url', 'url'], '').replace('&', '&amp;')

        seg = self.safe_get(video, ['segment_base', 'SegmentBase'], {})
        idx_range  = self.safe_get(seg, ['index_range', 'indexRange'], '0-0')
        init_range = self.safe_get(seg, ['initialization', 'Initialization'], '0-0')

        # 关键：视频URL为空则跳过
        if not v_base:
            return ''
        # 关键：width/height为0可能导致播放器拒绝解码
        if int(v_width) == 0 or int(v_height) == 0:
            return ''

        # XML安全转义所有属性值
        def x(s):
            return html_module.escape(str(s), quote=True)

        mpd = '<?xml version="1.0" encoding="utf-8"?>
'
        mpd += f'<MPD xmlns="urn:mpeg:dash:schemas:mpd:2011" minBufferTime="PT{min_buf}S" type="static" mediaPresentationDuration="PT{duration}S" profiles="urn:mpeg:dash:profile:isoff-on-demand:2011">
'
        mpd += f'  <Period duration="PT{duration}S">
'
        mpd += f'    <AdaptationSet contentType="video" mimeType="{x(v_mime)}" segmentAlignment="true" startWithSAP="1">
'
        mpd += f'      <Representation id="{x(v_id)}" bandwidth="{x(v_bw)}" codecs="{x(v_codecs)}" width="{x(v_width)}" height="{x(v_height)}" frameRate="{x(v_fps)}" sar="{x(v_sar)}">
'
        mpd += f'        <BaseURL>{v_base}</BaseURL>
'
        mpd += f'        <SegmentBase indexRange="{x(idx_range)}">
'
        mpd += f'          <Initialization range="{x(init_range)}"/>
'
        mpd += '        </SegmentBase>
'
        mpd += '      </Representation>
'
        mpd += '    </AdaptationSet>
'

        for audio in (audio_list or []):
            if not isinstance(audio, dict):
                continue
            a_id = self.safe_get(audio, ['id', 'Id'], 0)
            a_bw = self.safe_get(audio, ['bandwidth'], 0)
            a_codecs = self.safe_get(audio, ['codecs'], '')
            a_mime = self.safe_get(audio, ['mime_type', 'mimeType'], 'audio/mp4')
            a_base = self.safe_get(audio, ['baseUrl', 'base_url', 'url'], '').replace('&', '&amp;')

            if not a_base:
                continue

            a_seg = self.safe_get(audio, ['segment_base', 'SegmentBase'], {})
            a_idx  = self.safe_get(a_seg, ['index_range', 'indexRange'], '0-0')
            a_init = self.safe_get(a_seg, ['initialization', 'Initialization'], '0-0')

            if a_id == 30251:
                label = '无损Hi-Res'
            elif a_id == 30250:
                label = '杜比全景声'
            elif a_id == 30280:
                label = '192k高音质'
            elif a_id == 30232:
                label = '132k标准'
            elif a_id == 30216:
                label = '64k流畅'
            else:
                label = f'音质_{a_id}'

            mpd += f'    <AdaptationSet contentType="audio" mimeType="{x(a_mime)}" segmentAlignment="true" startWithSAP="0" lang="{x(label)}">
'
            mpd += f'      <Label>{x(label)}</Label>
'
            mpd += f'      <Representation id="audio_{x(a_id)}" bandwidth="{x(a_bw)}" codecs="{x(a_codecs)}">
'
            mpd += f'        <BaseURL>{a_base}</BaseURL>
'
            mpd += f'        <SegmentBase indexRange="{x(a_idx)}">
'
            mpd += f'          <Initialization range="{x(a_init)}"/>
'
            mpd += '        </SegmentBase>
'
            mpd += '      </Representation>
'
            mpd += '    </AdaptationSet>
'

        mpd += '  </Period>
</MPD>'
        return mpd

    def homeContent(self, filter):
        result = {"class": [
            {"type_id": "1001", "type_name": "影视"},
            {"type_id": "1002", "type_name": "娱乐"},
            {"type_id": "1003", "type_name": "音乐"},
            {"type_id": "1004", "type_name": "舞蹈"},
            {"type_id": "1005", "type_name": "动画"},
            {"type_id": "1006", "type_name": "绘画"},
            {"type_id": "1007", "type_name": "鬼畜"},
            {"type_id": "1008", "type_name": "游戏"},
            {"type_id": "1009", "type_name": "资讯"},
            {"type_id": "1010", "type_name": "知识"},
            {"type_id": "1011", "type_name": "人工智能"},
            {"type_id": "1012", "type_name": "科技数码"},
            {"type_id": "1013", "type_name": "汽车"},
            {"type_id": "1014", "type_name": "时尚美妆"},
            {"type_id": "1015", "type_name": "家装房产"},
            {"type_id": "1016", "type_name": "户外潮流"},
            {"type_id": "1017", "type_name": "健身"},
            {"type_id": "1018", "type_name": "体育运动"},
            {"type_id": "1019", "type_name": "手工"},
            {"type_id": "1020", "type_name": "美食"},
            {"type_id": "1021", "type_name": "小剧场"},
            {"type_id": "1022", "type_name": "旅游出行"},
            {"type_id": "1023", "type_name": "三农"},
            {"type_id": "1024", "type_name": "动物"},
            {"type_id": "1025", "type_name": "亲子"},
            {"type_id": "1026", "type_name": "健康"},
            {"type_id": "1027", "type_name": "情感"},
            {"type_id": "1028", "type_name": "神秘学"},
            {"type_id": "1029", "type_name": "VLOG"},
            {"type_id": "1030", "type_name": "生活兴趣"},
            {"type_id": "1031", "type_name": "生活经验"}
        ]}
        return result

    def homeVideoContent(self):
        pass

    def format_views(self, num):
        if num >= 10000:
            return f"{num / 10000:.1f}万"
        return str(num)

    def categoryContent(self, cid, pg, filter, ext):
        result = {}
        videos = []
        url = f'{xurl}/x/web-interface/region/feed/rcmd?display_id={pg}&request_cnt=15&from_region={cid}'
        res = requests.get(url=url, headers=headerx, timeout=10)
        res.encoding = "utf-8"
        kjson = res.json()
        for i in kjson.get('data', {}).get('archives', []):
            id = i.get('bvid', '')
            name = i.get('title', '未知')
            pic = i.get('cover', '')
            remarks = self.format_views(i.get('stat', {}).get('view', 0))
            video = {
                "vod_id": id,
                "vod_name": name,
                "vod_pic": pic,
                "vod_remarks": '播放量:' + remarks
            }
            videos.append(video)
        result = {
            'list': videos,
            'page': pg,
            'pagecount': 9999,
            'limit': 90,
            'total': 999999
        }
        return result

    def detailContent(self, ids):
        result = {}
        videos = []
        did = ids[0] if isinstance(ids, list) else ids
        url = f'https://www.bilibili.com/video/{did}'
        res = requests.get(url=url, headers=headerx, timeout=10)
        res.encoding = "utf-8"
        res_text = res.text

        kjson = {}
        match = re.search(r'window\.__INITIAL_STATE__\s*=\s*({.+?});', res_text)
        if match:
            try:
                kjson = json.loads(match.group(1))
            except Exception:
                pass

        video_data = kjson.get('videoData', {})
        name = video_data.get('title') or '未知标题'
        remarks = video_data.get('tname') or ''
        director = video_data.get('owner', {}).get('name') or '未知作者'
        content = video_data.get('desc') or ''

        aid = video_data.get('aid') or 0
        pages = video_data.get('pages') or []
        cid = video_data.get('cid') or 0
        if not cid and pages:
            cid = pages[0].get('cid') or 0

        play_url = ""
        if pages:
            for page in pages:
                p_cid = page.get('cid') or 0
                p_title = page.get('part') or f"P{page.get('page', 1)}"
                p_title = str(p_title).replace('#', '﹟').replace('$', '﹩')
                play_url += p_title + '$' + str(aid) + '+' + str(p_cid) + '#'
            play_url = play_url[:-1]
        else:
            play_url = str(name).replace('#', '﹟').replace('$', '﹩') + '$' + str(aid) + '+' + str(cid)

        video = {
            "vod_id": did,
            "vod_name": name,
            "vod_actor": '',
            "vod_director": director,
            "vod_content": '解析支持 腾、茫、B站、人人（4K），优、奇、华数、咪咕、乐事、PP（1080、720）' + content,
            "vod_remarks": remarks,
            "vod_year": '',
            "vod_area": '',
            "vod_play_from": 'B站',
            "vod_play_url": play_url
        }
        videos.append(video)
        result['list'] = videos
        return result

    # ========== 关键修复：AVC优先排序 + 直链备选 + 严格空值检查 ==========
    def playerContent(self, flag, id, vipFlags):
        if '+' not in id:
            return {'jx': 1, 'parse': 1, 'url': id, 'header': headerx}

        parts = id.split('+')
        aid = parts[0]
        cid = parts[1]

        try:
            img_key, sub_key = self.get_wbi_keys()

            params = {
                'avid': aid,
                'cid': cid,
                'qn': '127',
                'fnval': '4048',
                'fourk': '1'
            }
            query = self.enc_wbi(params, img_key, sub_key)
            dash_url = f'https://api.bilibili.com/x/player/playurl?{query}'

            resp = requests.get(dash_url, headers=headerx, timeout=10)
            data = resp.json()

            # 关键修复：先尝试取durl直链作为备选
            durls = data.get('data', {}).get('durl', []) if data.get('data') else []
            fallback_url = ''
            if durls and durls[0].get('url'):
                fallback_url = durls[0]['url']

            if not data.get('data') or not data['data'].get('dash'):
                if fallback_url:
                    return {'parse': 0, 'jx': 0, 'url': fallback_url, 'header': headerx}
                return {'jx': 1, 'parse': 1, 'url': f'https://www.bilibili.com/video/av{aid}', 'header': headerx}

            dash = data['data']['dash']
            videos = dash.get('video') or []
            duration = dash.get('duration') or 0
            min_buf = dash.get('min_buffer_time') or 1.5

            # 如果duration为0，尝试从durl获取时长（兜底）
            if duration == 0 and durls:
                duration = durls[0].get('length', 0) // 1000

            # 收集音频
            raw_audios = []
            if dash.get('audio'):
                raw_audios.extend(dash['audio'])
            flac_audio = dash.get('flac', {}).get('audio')
            if flac_audio:
                if isinstance(flac_audio, list):
                    raw_audios.extend(flac_audio)
                else:
                    raw_audios.append(flac_audio)
            dolby_audio = dash.get('dolby', {}).get('audio')
            if dolby_audio:
                if isinstance(dolby_audio, list):
                    raw_audios.extend(dolby_audio)
                else:
                    raw_audios.append(dolby_audio)

            audio_priority = {30251: 1, 30250: 2, 30280: 3, 30232: 4, 30216: 5}
            raw_audios.sort(key=lambda a: audio_priority.get(self.safe_get(a, ['id'], 0), 99))

            audio_list = []
            seen_audio = set()
            for a in raw_audios:
                if not isinstance(a, dict):
                    continue
                a_id = self.safe_get(a, ['id'], 0)
                if a_id and a_id not in seen_audio:
                    seen_audio.add(a_id)
                    audio_list.append(a)

            # 画质名称映射
            formats = data['data'].get('support_formats') or []
            if not formats:
                aq = data['data'].get('accept_quality') or []
                ad = data['data'].get('accept_description') or []
                formats = [{'quality': q, 'display_desc': ad[i] if i < len(ad) else str(q)} for i, q in enumerate(aq)]

            qn_map = {}
            for f in formats:
                qn_map[f['quality']] = f.get('display_desc') or f.get('new_description') or str(f['quality'])

            urls_array = []
            seen_streams = set()

            # ========== 关键修复：AVC编码优先，解决播放器不支持HEVC/AV1导致黑屏 ==========
            def codec_priority(v):
                if not isinstance(v, dict):
                    return 99
                c = str(self.safe_get(v, ['codecs'], '')).lower()
                if 'avc' in c:
                    return 0
                if 'hev' in c or 'hvc' in c:
                    return 1
                if 'av01' in c:
                    return 2
                return 3

            videos.sort(key=lambda v: (codec_priority(v), -int(self.safe_get(v, ['id'], 0))))

            for v in videos:
                if not isinstance(v, dict):
                    continue
                qn = int(self.safe_get(v, ['id'], 0))
                if qn == 0:
                    continue

                codecs_str = self.safe_get(v, ['codecs'], '')
                codec_name = ''
                if 'avc' in codecs_str:
                    codec_name = 'AVC'
                elif 'hev' in codecs_str or 'hvc' in codecs_str:
                    codec_name = 'HEVC'
                elif 'av01' in codecs_str:
                    codec_name = 'AV1'
                elif 'dvh' in codecs_str or 'dve' in codecs_str:
                    codec_name = '杜比'

                if qn <= 80:
                    stream_key = str(qn)
                    codec_name = ''
                else:
                    stream_key = f"{qn}_{codec_name}"

                if stream_key in seen_streams:
                    continue
                seen_streams.add(stream_key)

                base_name = qn_map.get(qn, f'画质{qn}')
                if qn == 126 or codec_name == '杜比':
                    base_name = '杜比视界'
                elif qn == 125:
                    base_name = f"HDR真彩色({codec_name or 'HEVC'})"
                else:
                    if codec_name:
                        base_name += f"({codec_name})"

                mpd = self.build_mpd(v, audio_list, duration, min_buf)
                if not mpd:
                    continue

                data_uri = 'data:application/dash+xml;base64,' + self.base64_encode_str(mpd)
                urls_array.append({
                    'name': base_name,
                    'url': data_uri,
                    'qn': qn,
                    'bw': int(self.safe_get(v, ['bandwidth'], 0))
                })

            # 关键修复：如果没有有效DASH流，回退到durl直链
            if not urls_array:
                if fallback_url:
                    return {'parse': 0, 'jx': 0, 'url': fallback_url, 'header': headerx}
                return {'jx': 1, 'parse': 1, 'url': f'https://www.bilibili.com/video/av{aid}', 'header': headerx}

            # 构建返回数组 [画质名, URL, 画质名, URL...]
            arr = []
            for q in urls_array:
                arr.append(q['name'])
                arr.append(q['url'])

            # 如果有直链，添加到末尾作为备选
            if fallback_url:
                arr.append('直链(MP4)')
                arr.append(fallback_url)

            return {
                'parse': 0,
                'jx': 0,
                'url': arr,
                'danmaku': f'https://api.bilibili.com/x/v1/dm/list.so?oid={cid}',
                'header': json.dumps(headerx)
            }
        except Exception as e:
            return {'jx': 1, 'parse': 1, 'url': f'https://www.bilibili.com/video/av{aid}', 'header': headerx}

    def searchContentPage(self, key, quick, page):
        result = {}
        videos = []
        if not page:
            page = 1
        url = f'https://search.bilibili.com/all?keyword={quote(key)}&page={page}'
        res = requests.get(url=url, headers=headerx, timeout=10)
        res.encoding = "utf-8"
        doc = BeautifulSoup(res.text, 'lxml')
        soups = doc.find_all('div', class_='bili-video-card__wrap')
        for i in soups:
            a_tag = i.find('a')
            if not a_tag or 'href' not in a_tag.attrs:
                continue
            href = a_tag['href']
            if 'www.bilibili.com/video' not in href:
                continue

            if href.startswith('//'):
                id = 'https:' + href
            elif href.startswith('/'):
                id = 'https://www.bilibili.com' + href
            elif href.startswith('http'):
                id = href
            else:
                continue
            id = id.replace('https://www.bilibili.com/video/', '').replace('/', '')

            img_tag = i.find('img')
            name = img_tag['alt'] if img_tag and 'alt' in img_tag.attrs else '未知'

            remark_div = i.find('div', class_='bili-video-card__stats--left')
            if remark_div:
                text = remark_div.text.strip()
                num_str = text.split('万')[0] if '万' in text else text
                try:
                    num = float(num_str)
                    if num >= 10000:
                        remarks = f"{num / 10000:.1f}亿播放量"
                    else:
                        remarks = f"{num:.1f}万播放量"
                except ValueError:
                    remarks = text
            else:
                remarks = ''

            source_tag = i.find('source')
            if source_tag and 'srcset' in source_tag.attrs:
                srcset = source_tag['srcset']
                if srcset.startswith('//'):
                    pic = 'https:' + srcset
                elif srcset.startswith('/'):
                    pic = 'https://www.bilibili.com' + srcset
                elif srcset.startswith('http'):
                    pic = srcset
                else:
                    pic = ''
            else:
                pic = ''

            video = {
                "vod_id": id,
                "vod_name": name,
                "vod_pic": pic,
                "vod_remarks": remarks
            }
            videos.append(video)

        result['list'] = videos
        result['page'] = page
        result['pagecount'] = 9999
        result['limit'] = 90
        result['total'] = 999999
        return result

    def searchContent(self, key, quick, pg="1"):
        return self.searchContentPage(key, quick, pg)

    def localProxy(self, params):
        if params['type'] == "m3u8":
            return self.proxyM3u8(params)
        elif params['type'] == "media":
            return self.proxyMedia(params)
        elif params['type'] == "ts":
            return self.proxyTs(params)
        return None
