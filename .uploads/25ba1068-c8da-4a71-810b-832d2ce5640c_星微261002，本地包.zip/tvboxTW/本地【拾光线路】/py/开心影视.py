# -*- coding: utf-8 -*-
# 开心影院 (kxyytv.com) TVBox 爬虫源
# 模板: MacCMS v10 风格自定义模板 / v4
# 路由:
#   首页     https://www.kxyytv.com/
#   分类     /vodshow/{tid}--------{page}---.html   (tid: 1=电影 2=电视剧 3=综艺 4=动漫 26=短剧)
#   详情     /voddetail/{id}.html
#   播放     /vodplay/{id}-{from}-{ep}.html         (player_data 内 encrypt:0 明文 m3u8)
#   搜索     /index.php/ajax/suggest?mid=1&wd={key} (JSON)
# 线路: 1=BD源 2=TT源 3=LZ源 4=BF源 (页面出现顺序: BD源(#tabs-home-1) BF源(#tabs-home-4) LZ源(#tabs-home-3) TT源(#tabs-home-2))
import re
import json
from urllib.parse import quote

from base.spider import Spider


class Spider(Spider):
    def init(self, extend=""):
        self.session = requests_get_session()
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36",
            "Referer": "https://www.kxyytv.com/",
        }
        self.session.headers.update(self.headers)

    def getName(self):
        return "kxyytv"

    def homepageContent(self, filter):
        return self.homeContent(filter)

    def homeContent(self, filter):
        result = {}
        result["class"] = [
            {"type_id": "1", "type_name": "电影"},
            {"type_id": "2", "type_name": "电视剧"},
            {"type_id": "3", "type_name": "综艺"},
            {"type_id": "4", "type_name": "动漫"},
            {"type_id": "26", "type_name": "短剧"},
        ]
        result["filters"] = {}
        html = self._get("https://www.kxyytv.com/")
        result["list"] = self._parse_list(html)
        return result

    def homeVideoContent(self):
        return self.homeContent(False)

    def categoryContent(self, tid, pg, filter, extend):
        try:
            page = max(1, int(pg))
        except (TypeError, ValueError):
            page = 1
        url = "https://www.kxyytv.com/vodshow/%s--------%d---.html" % (quote(str(tid)), page)
        html = self._get(url)
        items = self._parse_list(html)
        # 解析总页数(分页控件最后一级)
        pagecount = self._parse_pagecount(html)
        return {"page": page, "pagecount": pagecount, "limit": len(items),
                "total": pagecount * max(len(items), 1), "list": items}

    def detailContent(self, ids):
        if not ids:
            return {"list": []}
        vid = ids[0]
        if not str(vid).isdigit():
            vid = re.sub(r"\D", "", str(vid))
        url = "https://www.kxyytv.com/voddetail/%s.html" % vid
        html = self._get(url)

        vod = {}
        vod["vod_id"] = vid
        m = re.search(r'<h1[^>]*>(.*?)</h1>', html, re.S)
        vod["vod_name"] = re.sub(r"<[^>]+>", "", m.group(1)).strip() if m else ""
        vod["vod_pic"] = self._detail_pic(html)
        m = re.search(r'<meta name="description" content="([^"]*)"', html)
        vod["vod_content"] = (m.group(1).replace("&amp;", "&") if m else "")
        m = re.search(r'<span class="badge bg-pink[^"]*"[^>]*>([^<]+)</span>', html)
        vod["vod_remarks"] = m.group(1).strip() if m else ""

        # 线路: 按页面出现顺序提取 #tabs-home-{from} 及其中剧集链接
        lines_from = []
        line_names = []
        for m in re.finditer(
            r'<a[^>]+href="#tabs-home-(\d+)"[^>]*>.*?</svg>\s*([^<]{1,12}?源)\s*&nbsp;',
            html, re.S,
        ):
            fid = m.group(1)
            name = m.group(2).strip()
            if fid not in lines_from:
                lines_from.append(fid)
                line_names.append(name)
        # 兜底: 从 tab-content 容器反推
        if not lines_from:
            for m in re.finditer(r'id="tabs-home-(\d+)"', html):
                fid = m.group(1)
                if fid not in lines_from:
                    lines_from.append(fid)
                    line_names.append("线路%s" % fid)

        play_urls = []
        for fid in lines_from:
            # 取该 tab 容器里的剧集 (href=/vodplay/{vid}-{fid}-{ep}.html)
            seg = ""
            midx = re.search(r'id="tabs-home-%s"' % fid, html)
            if midx:
                nxt = re.search(r'id="tabs-home-\d+"', html[midx.end():])
                seg = html[midx.end():midx.end() + (nxt.start() if nxt else 4000)]
            eps = re.findall(
                r'href="/vodplay/%s-%s-(\d+)\.html"[^>]*>([^<]+)</a>' % (re.escape(vid), fid),
                seg,
            )
            if not eps:
                eps = re.findall(
                    r'href="/vodplay/%s-%s-(\d+)\.html"[^>]*>([^<]+)</a>' % (re.escape(vid), fid),
                    html,
                )
            tail = []
            for ep, title in eps:
                tail.append("%s$%s-%s-%s" % (title.strip() or ep, vid, fid, ep))
            if tail:
                play_urls.append("#".join(tail))

        if play_urls:
            vod["vod_play_from"] = "$$$".join(line_names[:len(play_urls)])
            vod["vod_play_url"] = "$$$".join(play_urls)
        else:
            vod["vod_play_from"] = "在线"
            vod["vod_play_url"] = "第1集$%s-1-1" % vid
        return {"list": [vod]}

    def searchContent(self, key, quick):
        key = str(key)
        try:
            url = "https://www.kxyytv.com/index.php/ajax/suggest?mid=1&wd=%s" % quote(key)
            text = self._get(url)
            obj = json.loads(text)
            items = obj.get("list") or []
        except Exception:
            items = []
        result = {"list": []}
        for it in items:
            result["list"].append({
                "vod_id": str(it.get("id")),
                "vod_name": it.get("name", ""),
                "vod_pic": it.get("pic", ""),
                "vod_remarks": "",
                "vod_content": "",
            })
        return result

    def playerContent(self, flag, id, vipFlags):
        body = dict(id) if isinstance(id, dict) else None
        pid = str((body or {}).get("id") if body else id or "")
        # id 形如 "/vodplay/..." 或 "{vid}-{from}-{ep}"
        play_page = ""
        if pid.startswith("/vodplay/"):
            play_page = "https://www.kxyytv.com" + pid
        else:
            parts = pid.split("-")
            if len(parts) >= 3 and parts[0].isdigit():
                vid, fid, ep = parts[0], parts[1], parts[2]
                play_page = "https://www.kxyytv.com/vodplay/%s-%s-%s.html" % (vid, fid, ep)
        if not play_page:
            return {}
        html = self._get(play_page)
        url = self._extract_player_url(html)
        if not url:
            return {}
        # NBY/YX源: player_data.url 为加密串, 需经 nby.php 三步签名链路换真实 m3u8
        if not url.startswith("http"):
            url = self._nby_resolve(url)
            if not url:
                return {}
        elif not self._probe_media(url):
            # 直链 m3u8 探测失败, 重试一次
            if not self._probe_media(url):
                return {}
        return {"parse": 0, "jx": 0, "playUrl": "", "url": url,
                "header": {"User-Agent": self.headers["User-Agent"], "Referer": "https://www.kxyytv.com/"}}

    def _probe_media(self, url):
        """真直链验证门禁: 请求 m3u8 并确认返回 HLS 媒体流"""
        try:
            r = self.session.get(url, timeout=10, stream=True)
            try:
                head = r.content[:300].decode("utf-8", "ignore")
            finally:
                r.close()
            return "#EXTM3U" in head
        except Exception:
            return False

    def _nby_resolve(self, enc):
        """NBY 加密串 -> 签名 m3u8(jmurl)。三步实时: get_signed_url -> signed_url -> jmurl"""
        try:
            base = "https://www.kxyytv.com/static/player/nby.php"
            r1 = self.session.get(base + "?get_signed_url=1&url=" + enc, timeout=15)
            signed = r1.json().get("signed_url") or ""
            if not signed:
                return ""
            r2 = self.session.get(base + signed, timeout=15)
            return str(r2.json().get("jmurl") or "")
        except Exception:
            return ""

    def _extract_player_url(self, html):
        m = re.search(r'player_data\s*=\s*({.*?})\s*;', html, re.S)
        if not m:
            m = re.search(r'"url"\s*:\s*"([^"]+)"', html)
            if m:
                return m.group(1).replace("\\/", "/")
            return ""
        raw = m.group(1)
        obj = None
        try:
            obj = json.loads(raw.replace("\\/", "/"))
        except Exception:
            pass
        if not obj:
            # 双重转义时逐层还原
            try:
                obj = json.loads(raw.encode("utf-8").decode("unicode_escape")
                                 .replace("\\/", "/"))
            except Exception:
                return ""
        if not obj:
            return ""
        url = obj.get("url") or ""
        # encrypt=1 时作为兜底尝试直接返回(多数 MacCMS 也仍给直链)
        return str(url)

    # ---------- 内部工具 ----------

    def _parse_list(self, html):
        items = []
        pattern = re.compile(
            r'<a[^>]+href="(/voddetail/(\d+)\.html)"[^>]*>(?:\s*<img[^>]+src="([^"]+)"[^>]*>)?'
            r'(?:[^<]*<[^>]*>)*?\s*(?:<span class="badge[^"]*"[^>]*>([^<]*)</span>)?'
            r'</a>\s*(?:<div class="card-body[^"]*"[^>]*>)?\s*<h3[^>]*class="[^"]*card-title[^"]*"[^>]*>(.*?)</h3>',
            re.S,
        )
        for m in pattern.finditer(html):
            href, vid, pic, badge, title = m.groups()
            title = re.sub(r"<[^>]+>", "", title or "").strip()
            items.append({
                "vod_id": vid,
                "vod_name": title,
                "vod_pic": pic or "",
                "vod_remarks": (badge or "").strip(),
                "vod_content": "",
            })
        # 备用: 宽松匹配 title 属性
        if not items:
            pat2 = re.compile(
                r'<a[^>]+href="/voddetail/(\d+)\.html"[^>]*title="([^"]*)"[^>]*>\s*<img[^>]+src="([^"]+)"',
                re.S,
            )
            for m in pat2.finditer(html):
                items.append({
                    "vod_id": m.group(1),
                    "vod_name": m.group(2),
                    "vod_pic": m.group(3),
                    "vod_remarks": "",
                    "vod_content": "",
                })
        return items

    def _parse_pagecount(self, html):
        # 分页控件 <a href="/vodshow/2--------{N}---.html">N</a>
        nums = []
        for m in re.finditer(r'href="/vodshow/\d+--------(\d+)---\.html"', html):
            try:
                nums.append(int(m.group(1)))
            except ValueError:
                pass
        return max(nums) if nums else 1

    def _detail_pic(self, html):
        m = re.search(r'<meta property="og:image" content="([^"]+)"', html)
        if m:
            return m.group(1)
        m = re.search(r'class="[^"]*(?:cover2|poster)[^"]*"[^>]*>\s*<img[^>]+src="([^"]+)"', html)
        if m:
            return m.group(1)
        m = re.search(r'<img[^>]+src="(https?://[^"]+)"[^>]*>', html)
        return m.group(1) if m else ""

    def _get(self, url):
        r = self.session.get(url, timeout=15)
        r.raise_for_status()
        return r.text


def requests_get_session():
    import requests
    return requests.Session()