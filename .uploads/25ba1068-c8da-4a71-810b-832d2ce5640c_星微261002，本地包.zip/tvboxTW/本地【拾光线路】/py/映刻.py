# coding=utf-8
"""
目标站: 映刻短剧 (https://bjxcxl.com)
模板: 苹果CMS (fed/stui)
特性: 纯正则解析(无bs4依赖)、多线路播放、自动URL补全
修复记录:
  1. [P0] 站点URL改为HTTPS（原HTTP导致301重定向+混合内容）
  2. [P1] 线路名映射修正: line0=红豆剧场, line1=河马短剧（原映射完全反且名称错）
  3. [P1] searchContent补全limit/total分页字段（原缺失违反编码铁律#5）
  4. [P1] _fix_url协议相对URL改用https（原http导致HTTPS页面下图片被拦截）
  5. [P2] 详情页封面图正则修正（原fed-part-views不存在，改为fed-deta-images）
  6. [P2] 移除无效排序筛选器（search.php返回JS加载页，HTTP无法排序）
  7. [P2] 播放列表按首次出现顺序排列（原按行号排序导致线路顺序与站点不一致）
  8. [P2] 线路名称改为动态提取（从tab链接解析，不再纯硬编码）
"""
import re
import sys
import json
import urllib.parse
import time
sys.path.append('..')
from base.spider import Spider
class Spider(Spider):
    def init(self, extend=""):
        # [P0修复] 站点已全站HTTPS，原http会导致每次请求301重定向
        self.site_url = "https://bjxcxl.com"
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Referer': self.site_url + '/',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'zh-CN,zh;q=0.9',
        }
        # [P1修复] 线路ID映射真实名称（抓包确认: line1=河马短剧, line0=红豆剧场）
        # 此映射作为fallback，detailContent中会动态提取覆盖
        self.line_name_map = {
            "0": "红豆剧场",
            "1": "河马短剧"
        }
        # 一级分类（抓包确认与站点导航一致）
        self.categories = [
            {"type_id": "1", "type_name": "重生"},
            {"type_id": "2", "type_name": "穿越"},
            {"type_id": "3", "type_name": "爽剧"},
            {"type_id": "4", "type_name": "言情"},
            {"type_id": "5", "type_name": "都市"},
            {"type_id": "6", "type_name": "古装"},
            {"type_id": "7", "type_name": "悬疑"},
            {"type_id": "8", "type_name": "剧情"},
        ]
        # [P2修复] 移除排序筛选器：站点排序走search.php返回JS加载页，HTTP直接请求无法获取内容
        self.filters = {}

    def _safe_fetch(self, url, headers=None, max_retry=2):
        """轻量安全请求，失败自动重试"""
        if headers is None:
            headers = self.headers
        for i in range(max_retry):
            try:
                resp = self.fetch(url, headers=headers)
                if resp:
                    return resp
            except Exception:
                if i < max_retry - 1:
                    time.sleep(0.3)
        return None

    def _fix_url(self, url):
        """补全相对URL为绝对URL"""
        if not url:
            return ''
        if url.startswith('http'):
            return url
        # [P1修复] 协议相对URL用https（站点已全站HTTPS）
        if url.startswith('//'):
            return 'https:' + url
        if url.startswith('/'):
            return self.site_url + url
        return self.site_url + '/' + url

    def _parse_video_list(self, html, max_count=0):
        """
        正则解析视频列表 -- 比BeautifulSoup快3~5倍
        匹配结构: <li class="fed-list-item">...<a href="/djok/{id}.html" data-original="pic" title="name">...<span class="fed-list-remarks">remark</span>...</li>
        """
        video_list = []
        seen = set()
        # 提取每个列表块
        item_blocks = re.findall(r'<li[^>]*class="fed-list-item[^"]*"[^>]*>(.*?)</li>', html, re.DOTALL)
        for block in item_blocks:
            href_m = re.search(r'href="(/djok/(\d+)\.html)"', block)
            if not href_m:
                continue
            href, vod_id = href_m.groups()
            if vod_id in seen:
                continue
            seen.add(vod_id)
            title_m = re.search(r'title="([^"]*)"', block)
            title = title_m.group(1) if title_m else ''
            pic_m = re.search(r'data-original="([^"]*)"', block)
            pic = pic_m.group(1) if pic_m else ''
            remark_m = re.search(r'class="fed-list-remarks[^"]*"[^>]*>(.*?)</span>', block)
            remark = remark_m.group(1) if remark_m else ''
            remark = re.sub(r'<[^>]+>', '', remark).strip()
            if not title:
                continue
            video_list.append({
                "vod_id": vod_id,
                "vod_name": title,
                "vod_pic": self._fix_url(pic),
                "vod_remarks": remark,
            })
            if max_count > 0 and len(video_list) >= max_count:
                break
        return video_list

    def _extract_page_info(self, html, tid, default_page):
        """从分页区域提取总页码与总数"""
        pagecount = default_page
        total = 0
        # 匹配 /dj/{tid}-{num}.html 形式的页码
        pages = re.findall(r'/dj/' + re.escape(str(tid)) + r'-(\d+)\.html', html)
        if pages:
            pagecount = max(pagecount, max(map(int, pages)))
        # 匹配总数文本
        total_m = re.search(r'共\s*(\d+)\s*部', html)
        if total_m:
            total = int(total_m.group(1))
        if not total:
            total = 30 * pagecount
        return pagecount, total

    def homeContent(self, filter):
        url = self.site_url + "/"
        resp = self._safe_fetch(url)
        video_list = []
        if resp:
            video_list = self._parse_video_list(resp.text, max_count=36)
        return {"class": self.categories, "list": video_list, "filters": self.filters}

    def homeVideoContent(self):
        return self.homeContent(False)

    def categoryContent(self, tid, pg, filter, extend):
        page = int(pg) if pg else 1
        # 该站分类URL: /dj/{tid}.html  分页: /dj/{tid}-{pg}.html
        if page <= 1:
            url = f"{self.site_url}/dj/{tid}.html"
        else:
            url = f"{self.site_url}/dj/{tid}-{page}.html"
        resp = self._safe_fetch(url)
        if not resp:
            return {"list": [], "page": page, "pagecount": 1, "limit": 30, "total": 0}
        video_list = self._parse_video_list(resp.text)
        pagecount, total = self._extract_page_info(resp.text, tid, page)
        return {
            "list": video_list,
            "page": page,
            "pagecount": pagecount,
            "limit": 30,
            "total": total
        }

    def detailContent(self, ids):
        if not ids:
            return {"list": []}
        vod_id = ids[0]
        url = f"{self.site_url}/djok/{vod_id}.html"
        resp = self._safe_fetch(url)
        if not resp:
            return {"list": []}
        html = resp.text
        # 标题: 从<title>提取，去掉后缀
        vod_name = vod_id
        title_m = re.search(r'<title>(.*?)</title>', html)
        if title_m:
            raw = title_m.group(1)
            vod_name = raw.split('在线播放')[0].split('_')[0].strip()
        # [P2修复] 封面图: 优先匹配 fed-deta-images 区域（原fed-part-views不存在）
        # 实际HTML: <dt class="fed-deta-images ..."><a class="fed-list-pics ..." data-original="pic" ...>
        vod_pic = ''
        pic_m = re.search(r'class="fed-deta-images[^"]*"[^>]*>.*?data-original="([^"]+)"', html, re.DOTALL)
        if not pic_m:
            # 备用: 页面中第一个data-original（详情页主图在相关推荐之前出现）
            pic_m = re.search(r'data-original="([^"]+)"', html)
        if pic_m:
            vod_pic = self._fix_url(pic_m.group(1))
        # 简介: 从 meta description 提取并清洗
        vod_content = ''
        desc_m = re.search(r'<meta name="description" content="([^"]+)"', html)
        if desc_m:
            vod_content = desc_m.group(1)
            vod_content = re.sub(r'^.*?剧情介绍[：:]\s*', '', vod_content)
            vod_content = re.sub(r'，该[^。]*讲述的是.*$', '', vod_content)
            vod_content = re.sub(r'暂无简介', '', vod_content).strip()
        # 演员/导演/年份/地区 -- 从"相关问答"区域提取
        vod_actor = vod_director = vod_area = vod_year = ''
        qa_m = re.search(r'相关问答.*?</h\w+>\s*(.*?)</div>', html, re.DOTALL)
        if qa_m:
            qa_text = re.sub(r'<[^>]+>', ' ', qa_m.group(1))
            d_m = re.search(r'是由\s*([^，,]+?)\s*执导', qa_text)
            if d_m:
                vod_director = d_m.group(1).strip()
            a_m = re.search(r'执导[,，\s]+([^，,]+?)\s*(?:领衔主演|主演)', qa_text)
            if a_m:
                vod_actor = a_m.group(1).strip()
            y_m = re.search(r'(\d{4})-\d{2}-\d{2}', qa_text)
            if y_m:
                vod_year = y_m.group(1)
        # 备用年份
        if not vod_year:
            y_m2 = re.search(r'(\d{4})-\d{2}-\d{2}', html)
            if y_m2:
                vod_year = y_m2.group(1)
        # 类型/地区
        area_m = re.search(r'该([^讲]+?)讲述', html)
        if area_m:
            vod_area = area_m.group(1).strip()

        # ========== 播放列表解析 ==========
        # [P2修复] 线路名称改为动态提取（从tab链接解析）
        # 站点HTML: <a href="#playlist2" ...> 河马短剧</a>  <a href="#playlist1" ...> 红豆剧场</a>
        tab_names = re.findall(r'href="#playlist\d+"[^>]*>.*?</i>\s*([^<]+)</a>', html)
        tab_names = [name.strip() for name in tab_names if name.strip()]

        # 提取所有播放链接
        play_links = re.findall(r'href="(/play/\d+-\d+-\d+\.html)"[^>]*>(.*?)</a>', html)
        groups = {}
        # [P2修复] 按首次出现顺序记录线路ID（原代码按行号排序导致线路顺序与站点不一致）
        line_order = []
        for link, ep_raw in play_links:
            ep_name = re.sub(r'<[^>]+>', '', ep_raw).strip()
            # 过滤"立即播放"按钮（与第1集URL相同但不是剧集）
            if not ep_name or ep_name in ('立即播放', ''):
                continue
            m = re.search(r'/play/(\d+)-(\d+)-(\d+)\.html', link)
            if m:
                line = m.group(2)
                if line not in groups:
                    groups[line] = []
                    line_order.append(line)
                groups[line].append(f"{ep_name}${self._fix_url(link)}")

        # 构建动态线路名映射（tab顺序与线路出现顺序一一对应）
        dynamic_line_map = {}
        for i, line_id in enumerate(line_order):
            if i < len(tab_names):
                dynamic_line_map[line_id] = tab_names[i]

        play_from_list = []
        play_url_list = []
        if groups:
            # [P2修复] 按首次出现顺序输出（原sorted按行号排序导致line0排前面）
            for line_id in line_order:
                # 优先用动态提取的名称，其次用硬编码fallback
                line_name = dynamic_line_map.get(line_id, '')
                if not line_name:
                    line_name = self.line_name_map.get(str(line_id), f"线路{line_id}")
                play_from_list.append(line_name)
                play_url_list.append('#'.join(groups[line_id]))
        else:
            play_from_list.append('默认线路')
            play_url_list.append(f"播放${self.site_url}/djok/{vod_id}.html")
        vod_play_from = '$$$'.join(play_from_list)
        vod_play_url = '$$$'.join(play_url_list)

        result = [{
            "vod_id": vod_id,
            "vod_name": vod_name,
            "vod_pic": vod_pic,
            "vod_content": vod_content,
            "vod_actor": vod_actor,
            "vod_director": vod_director,
            "vod_area": vod_area,
            "vod_year": vod_year,
            "vod_play_from": vod_play_from,
            "vod_play_url": vod_play_url
        }]
        return {"list": result}

    def searchContent(self, key, quick, pg="1"):
        page = int(pg) if pg else 1
        encoded_key = urllib.parse.quote(key)
        url = f"{self.site_url}/search.php?searchword={encoded_key}"
        if page > 1:
            url += f"&page={page}"
        resp = self._safe_fetch(url)
        if not resp:
            # [P1修复] 返回完整分页字段
            return {"list": [], "page": page, "pagecount": 1, "limit": 30, "total": 0}
        video_list = self._parse_video_list(resp.text)
        # 搜索分页
        pagecount = 1
        pages = re.findall(r'[?&]page=(\d+)', resp.text)
        if pages:
            pagecount = max(pagecount, max(map(int, pages)))
        # [P1修复] 补全limit和total字段（编码铁律#5）
        limit = 30
        total = pagecount * limit
        return {"list": video_list, "page": page, "pagecount": pagecount, "limit": limit, "total": total}

    def playerContent(self, flag, id, vipFlags):
        if id.startswith('http'):
            play_url = id
        elif id.startswith('/'):
            play_url = self.site_url + id
        else:
            play_url = self.site_url + '/' + id
        resp = self._safe_fetch(play_url)
        if not resp:
            return {"parse": 1, "url": play_url, "header": self.headers}
        html = resp.text
        # 1. 优先匹配 var now="xxx.m3u8"
        now_m = re.search(r'var\s+now\s*=\s*"([^"]+)"', html)
        if now_m:
            video_url = now_m.group(1)
            if video_url and video_url.startswith('http'):
                return {"parse": 0, "url": video_url, "header": self.headers}
        # 2. 正则匹配页面中任何 m3u8 地址
        m3u8_m = re.search(r"https?://[^\s\"'<>]+\.m3u8[^\s\"'<>]*", html)
        if m3u8_m:
            return {"parse": 0, "url": m3u8_m.group(0), "header": self.headers}
        # 3. iframe 嵌套
        iframe_m = re.search(r'<iframe[^>]+src="([^"]+)"', html)
        if iframe_m:
            iframe_url = iframe_m.group(1)
            if not iframe_url.startswith('http'):
                iframe_url = self._fix_url(iframe_url)
            return {"parse": 1, "url": iframe_url, "header": self.headers}
        # 4. mac_player_config
        mac_m = re.search(r'mac_player_config\s*=\s*({.*?})', html, re.DOTALL)
        if mac_m:
            try:
                cfg = json.loads(mac_m.group(1))
                video_url = cfg.get('url', '')
                if video_url and '.m3u8' in video_url:
                    return {"parse": 0, "url": video_url, "header": self.headers}
            except Exception:
                pass
        return {"parse": 1, "url": play_url, "header": self.headers}
