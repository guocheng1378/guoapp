#!/usr/bin/python
# kanju3.ai — 优化版
import re, json, time, random, hashlib, hmac, secrets
from urllib.parse import quote
import requests
from base.spider import Spider


class Spider(Spider):

    def init(self, extend=""):
        self.host = "https://kanju3.ai"
        self.api = "https://kanju3.ai"
        self.key = b"557d0e4ae929f438da6bd84412374e6086b8af09b3fed54bf22601d5bf8c54a0"
        self.bh = "dianyingtiantang-v2026.09.08.3-6a4fbcaaef9f-web"
        self.pv = "2026-07-05.library-v2.playback-v1"
        self.ua = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
        self.s = requests.Session()
        self.s.headers.update({"User-Agent": self.ua, "Referer": "https://kanju3.ai/", "Origin": "https://kanju3.ai", "Accept": "application/json"})
        self._new_session()

    def getName(self):
        return "看剧AI"

    def isVideoFormat(self, url):
        return any(x in url for x in [".m3u8", ".mp4", "/m3u8", "resolve://"])

    def destroy(self):
        pass

    def _nonce(self):
        return secrets.token_hex(16)

    def _sig(self, method, path, ts, nonce):
        msg = (method + "\n" + path + "\n" + ts + "\n" + nonce).encode("utf-8")
        return hmac.new(self.key, msg, hashlib.sha256).hexdigest()

    def _req(self, path, method="GET", body=None, retry=2):
        b = "" if body is None else json.dumps(body, separators=(",", ":"), ensure_ascii=False)
        for i in range(retry + 1):
            ts = str(int(time.time() * 1000))
            nonce = self._nonce()
            h = {
                "x-ai-movie-client-name": "dianyingtiantang-frontend",
                "x-ai-movie-client-version": "1.0.0",
                "x-ai-movie-build-version": self.bh,
                "x-ai-movie-protocol-version": self.pv,
                "x-ai-movie-timestamp": ts,
                "x-ai-movie-nonce": nonce,
                "x-ai-movie-signature": self._sig(method, path, ts, nonce),
            }
            if body is not None:
                h["Content-Type"] = "application/json"
            try:
                r = self.s.request(method, self.api + path, data=None if body is None else b.encode("utf-8"), headers=h, timeout=15, verify=False)
                if r.status_code in (429, 500, 502, 503) and i < retry:
                    time.sleep(0.6 + i)
                    continue
                if r.status_code >= 400:
                    return None
                return r.json()
            except Exception:
                if i < retry:
                    time.sleep(0.5)
                    continue
                return None
        return None

    def _new_session(self):
        try:
            self._req("/v1/users/anonymous", "POST", {})
        except Exception:
            pass

    def _card(self, c):
        return {
            "vod_id": c.get("id") or c.get("selected_variant_id") or "",
            "vod_name": (c.get("title") or "").strip(),
            "vod_pic": c.get("poster_url") or "",
            "vod_remarks": c.get("remarks") or (str(c.get("year")) if c.get("year") else ""),
            "vod_year": str(c.get("year") or ""),
            "vod_area": c.get("area") or "",
            "type_name": c.get("content_kind") or "",
        }

    def homeContent(self, filter):
        cates = [
            {"type_name": "电影", "type_id": "movie"},
            {"type_name": "剧集", "type_id": "series"},
            {"type_name": "动漫", "type_id": "anime"},
            {"type_name": "综艺", "type_id": "variety"},
            {"type_name": "纪录片", "type_id": "documentary"},
            {"type_name": "短剧", "type_id": "short_drama"},
            {"type_name": "体育", "type_id": "sports"},
        ]
        fl = {}
        for c in cates:
            fl[c["type_id"]] = [
                {"key": "sort", "name": "排序", "value": [{"n": "最新", "v": "latest"}, {"n": "热门", "v": "trending"}]},
            ]
        j = self._req("/v1/feed/home?scope=public&mode=preview&sections=3&cards=12")
        out = []
        if j and isinstance(j.get("sections"), list):
            seen = set()
            for sec in j["sections"]:
                for c in sec.get("cards") or []:
                    v = self._card(c)
                    if v["vod_id"] and v["vod_id"] not in seen:
                        seen.add(v["vod_id"])
                        out.append(v)
        return {"class": cates, "filters": fl, "list": out[:20]}

    def homeVideoContent(self):
        j = self._req("/v1/feed/home?scope=public&mode=preview&sections=3&cards=12")
        out = []
        if j and isinstance(j.get("sections"), list):
            seen = set()
            for sec in j["sections"]:
                for c in sec.get("cards") or []:
                    v = self._card(c)
                    if v["vod_id"] and v["vod_id"] not in seen:
                        seen.add(v["vod_id"])
                        out.append(v)
        return {"list": out[:20]}

    def categoryContent(self, tid, pg, filter, extend):
        try:
            pg = int(pg)
        except Exception:
            pg = 1
        ext = extend or {}
        if isinstance(ext, str):
            try:
                ext = json.loads(ext)
            except Exception:
                ext = {}
        params = {"page": str(pg), "limit": "24"}
        if tid and tid != "all":
            params["kind"] = tid
        sort = ext.get("sort") or "latest"
        if sort == "trending":
            params["sort"] = "trending"
        qs = "&".join(k + "=" + quote(str(v), safe="") for k, v in params.items())
        j = self._req("/v1/browse/catalog?" + qs)
        cards = (j or {}).get("cards") or []
        out = []
        seen = set()
        for c in cards:
            v = self._card(c)
            if v["vod_id"] and v["vod_id"] not in seen:
                seen.add(v["vod_id"])
                out.append(v)
        has_more = len(cards) >= 24
        return {"list": out, "page": pg, "pagecount": pg + 1 if has_more else pg, "limit": 24, "total": (pg + 1) * 24 if has_more else pg * 24}

    def detailContent(self, ids):
        vid = ids[0] if isinstance(ids, list) else ids
        j = self._req("/v1/catalog/" + quote(vid, safe=""))
        if not j or j.get("object") != "catalog.detail":
            return {"list": []}
        v = self._card(j)
        v["vod_content"] = j.get("description") or j.get("remarks") or ""
        v["vod_actor"] = " , ".join(j.get("actors") or [])
        v["vod_director"] = " , ".join(j.get("directors") or [])
        genres = j.get("genres") or []
        if genres:
            v["type_name"] = genres[0]
        eps = []
        pag = j.get("episode_pagination") or {}
        ep_list = j.get("episodes") or []
        if ep_list:
            eps.extend(ep_list)
        if pag.get("has_more"):
            limit = pag.get("limit") or 50
            total = pag.get("total_count") or pag.get("returned_count") or pag.get("available_episode_count") or 0
            try:
                total = int(total)
            except Exception:
                total = 0
            offset = len(eps)
            while offset < total:
                pj = self._req("/v1/catalog/" + quote(vid, safe="") + "/episodes?offset=" + str(offset) + "&limit=" + str(limit) + "&order=start")
                if not pj or not pj.get("episodes"):
                    break
                chunk = pj.get("episodes") or []
                eps.extend(chunk)
                if not ((pj.get("episode_pagination") or {}).get("has_more")):
                    break
                offset += len(chunk)
        groups = {}
        order = []
        for e in eps:
            line = e.get("episode_track") or "main"
            tok = e.get("token") or ""
            if not tok:
                continue
            name = (e.get("title") or e.get("display_name") or ("第" + str(e.get("number")) + "集" if e.get("number") else "播放")).strip()
            name = name.replace("#", " ").replace("$", " ")
            if line not in groups:
                groups[line] = []
                order.append(line)
            groups[line].append(name + "$" + tok)
        if not groups:
            return {"list": [v]}
        toks = groups.get("main") or next(iter(groups.values()))
        play_from = []
        play_url = []
        labels = self._line_labels(toks[0].split("$")[-1])
        if labels:
            seen_short = set()
            for lb in labels:
                name = lb["short"]
                if name in seen_short:
                    continue
                seen_short.add(name)
                play_from.append(name)
                play_url.append("#".join(toks))
        else:
            labelmap = {"main": "默认线路", "trailer": "预告"}
            for line in order:
                play_from.append(labelmap.get(line, line))
                play_url.append("#".join(groups[line]))
        v["vod_play_from"] = "$$$".join(play_from)
        v["vod_play_url"] = "$$$".join(play_url)
        return {"list": [v]}

    _LINE_MAP = {
        "1080zyk": "极速", "zyk": "极速", "极速资源": "极速", "极速": "极速",
        "1080P": "1080P", "1080p": "1080P",
        "720": "720P", "4K": "4K", "4k": "4K",
        "蓝光": "蓝光", "高清": "高清",
        "官方V": "官方V", "官方Z": "官方Z", "官方R": "官方R",
        "官方B": "官方B", "官方C": "官方C", "官方": "官方",
        "红牛": "红牛", "新浪": "新浪", "优酷": "优酷",
        "豪华": "豪华", "豆瓣": "豆瓣", "魔都": "魔都", "索尼": "索尼",
        "ikun": "ikun", "iqiyi": "爱奇艺", "暴风": "暴风",
        "U酷": "U酷", "金鹰": "金鹰", "猫眼": "猫眼", "速播": "速播",
        "茅台": "茅台", "无水印": "无水印", "无尽": "无尽",
        "电影天堂": "电影天堂", "非凡": "非凡", "最大": "最大",
        "量子": "量子", "360": "360", "牛牛": "牛牛", "抖音": "抖音",
    }
    _LINE_PRIORITY = ["1080P", "4K", "蓝光", "高清", "720P", "官方V", "官方Z", "官方R", "官方B", "官方C", "官方", "极速", "红牛", "新浪", "优酷", "爱奇艺", "豪华", "豆瓣", "索尼", "ikun", "暴风", "魔都", "金鹰", "猫眼", "速播", "U酷", "非凡", "量子", "360", "牛牛", "茅台", "无水印", "无尽", "电影天堂", "最大", "抖音"]

    def _short_label(self, raw):
        r = (raw or "").strip()
        best, best_len = "", 0
        for k, v in self._LINE_MAP.items():
            if k in r and len(k) > best_len:
                best, best_len = v, len(k)
        if best:
            return best
        return r[:6] if r else "未知"

    def _label_rank(self, short):
        try:
            return self._LINE_PRIORITY.index(short)
        except ValueError:
            return len(self._LINE_PRIORITY)

    def _line_labels(self, tok):
        try:
            j = self._req("/v1/playback/resolve/" + quote(tok, safe=""))
            los = (j or {}).get("line_options") or []
            result = []
            for lo in los:
                raw = (lo.get("display_label") or lo.get("label") or "").strip()
                if not raw:
                    continue
                short = self._short_label(raw)
                result.append({"short": short, "raw": raw, "weight": lo.get("preference_weight") or 0, "selected": lo.get("selected") or False, "id": lo.get("id") or lo.get("playback_source_id") or ""})
            result.sort(key=lambda x: (0 if x["selected"] else 1, -x["weight"], self._label_rank(x["short"])))
            return result
        except Exception:
            return []

    def searchContent(self, key, quick, pg="1"):
        try:
            pg = int(pg)
        except Exception:
            pg = 1
        qs = "q=" + quote(key or "", safe="") + "&page=" + str(pg) + "&limit=20"
        j = self._req("/v1/browse/catalog?" + qs)
        cards = (j or {}).get("cards") or []
        out = []
        seen = set()
        for c in cards:
            v = self._card(c)
            if v["vod_id"] and v["vod_id"] not in seen:
                seen.add(v["vod_id"])
                out.append(v)
        has_more = len(cards) >= 20
        return {"list": out, "page": pg, "pagecount": pg + 1 if has_more else pg, "limit": 20, "total": (pg + 1) * 20 if has_more else pg * 20}

    def searchContentPage(self, key, quick, pg):
        return self.searchContent(key, quick, pg)

    def _probe_media(self, url):
        if not url or not url.startswith(("http://", "https://")):
            return False
        try:
            r = self.s.head(url, headers={"User-Agent": self.ua}, timeout=10, verify=False, allow_redirects=True)
            ct = r.headers.get("Content-Type", "")
            return r.status_code == 200 and any(t in ct for t in ("video", "octet-stream", "mpegurl", "mp2t"))
        except Exception:
            try:
                r = self.s.get(url, headers={"User-Agent": self.ua}, timeout=10, verify=False, stream=True)
                ct = r.headers.get("Content-Type", "")
                r.close()
                return r.status_code == 200 and any(t in ct for t in ("video", "octet-stream", "mpegurl", "mp2t"))
            except Exception:
                return False

    def _resolve_line(self, tok, lo):
        if lo.get("resolved") and lo.get("url_kind") in ("m3u8", "mp4"):
            u = lo.get("url") or ""
            if u.startswith("http") and self._probe_media(u):
                return u
        ticket = lo.get("url") or ""
        if not ticket:
            return ""
        j = self._req("/v1/playback/resolve-line", "POST", {"playback_source_id": lo.get("playback_source_id") or lo.get("id"), "ticket": ticket})
        if j and isinstance(j.get("line"), dict):
            u = (j["line"].get("url") or "")
            if u.startswith("http") and self._probe_media(u):
                return u
        return ""

    def playerContent(self, flag, id, vipFlags):
        h = {"User-Agent": self.ua, "Referer": "https://kanju3.ai/"}
        empty = {"parse": 0, "playUrl": "", "url": "", "header": json.dumps(h)}
        j = self._req("/v1/playback/resolve/" + quote(id, safe=""))
        if not j or j.get("object") != "playback.resolve":
            return empty
        los = j.get("line_options") or []
        target = (flag or "").strip()
        if target:
            for lo in los:
                raw = (lo.get("display_label") or lo.get("label") or "").strip()
                short = self._short_label(raw)
                if short == target or raw == target:
                    u = self._resolve_line(id, lo)
                    if u:
                        return {"parse": 0, "playUrl": "", "url": u, "header": json.dumps(h)}
        los.sort(key=lambda x: (0 if x.get("selected") else 1, -(x.get("preference_weight") or 0), self._label_rank(self._short_label((x.get("display_label") or x.get("label") or "")))))
        for lo in los:
            u = self._resolve_line(id, lo)
            if u:
                return {"parse": 0, "playUrl": "", "url": u, "header": json.dumps(h)}
        return empty

    def localProxy(self, param):
        return [200, "text/plain", "", ""]
